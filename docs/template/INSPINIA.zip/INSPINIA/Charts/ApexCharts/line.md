# ApexCharts — Line (Dual Series)

**Categoria:** Chart
**Origem Inspinia:** `resources/views/charts/apex/line.blade.php`
**Plugins JS:** ApexCharts 5.3.5
**Uso no ArtFinal:** Dashboard 14.2 — "Receita x Inadimplência" (line dual)

---

## Descrição

Gráfico de linhas com **múltiplas séries**. O Dashboard 14.2 usa 2 séries no mesmo chart: receita recebida vs. inadimplência ao longo de 12 meses.

---

## Configuração mínima

```js
const options = {
    chart: {
        type: 'line',
        height: 320,
        toolbar: { show: false },
        zoom: { enabled: false },
    },
    stroke: {
        curve: 'smooth',
        width: 3,
    },
    series: [
        { name: 'Receita Recebida', data: [12000, 14000, 13500, 15000, 16000, 15500, 17000, 18000, 17500, 19000, 20000, 21000] },
        { name: 'Inadimplência', data: [2000, 2500, 2200, 3000, 2800, 3200, 3500, 3000, 3400, 3100, 2800, 2900] },
    ],
    xaxis: {
        categories: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez'],
    },
    yaxis: {
        labels: {
            formatter: (val) => 'R$ ' + (val / 1000).toFixed(0) + 'k',
        },
    },
    colors: ['#10B981', '#EF4444'], // verde, vermelho
    legend: { position: 'top' },
    tooltip: {
        y: { formatter: (val) => 'R$ ' + new Intl.NumberFormat('pt-BR', { minimumFractionDigits: 2 }).format(val) },
    },
}

new ApexCharts(document.querySelector('#chart-line-dual'), options).render()
```

---

## Exemplo de Uso (Dashboard 14.2)

```blade
<x-admin.chart-card title="Receita x Inadimplência (12 meses)" chart-id="receita-inadimplencia" :height="320">
    <livewire:admin.dashboard.grafico-receita-inadimplencia chart-id="receita-inadimplencia" />
</x-admin.chart-card>
```

```php
class GraficoReceitaInadimplencia extends Component
{
    public string $chartId;

    public function render()
    {
        $meses = collect(range(11, 0))->map(fn($i) => now()->subMonths($i));

        $receita = $meses->map(fn($m) => Parcela::pagas()
            ->whereYear('pago_em', $m->year)
            ->whereMonth('pago_em', $m->month)
            ->sum('valor_cobrado_centavos') / 100
        )->toArray();

        $inadimplencia = $meses->map(fn($m) => Parcela::vencidas()
            ->whereYear('vencimento', $m->year)
            ->whereMonth('vencimento', $m->month)
            ->sum('valor_cobrado_centavos') / 100
        )->toArray();

        $this->dispatch('chart-update',
            chartId: $this->chartId,
            type: 'line',
            data: [
                'series' => [
                    ['name' => 'Receita Recebida', 'data' => $receita],
                    ['name' => 'Inadimplência', 'data' => $inadimplencia],
                ],
                'categories' => $meses->map->format('M/y')->toArray(),
                'colors' => ['#10B981', '#EF4444'],
            ]
        );

        return view('livewire.admin.dashboard.grafico-receita-inadimplencia');
    }
}
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.2 Dashboard | **"Receita x Inadimplência" (confirmado no PRD)** |
| 14.17 Relatórios | Evolução de métricas no tempo |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P3 (Onda 4) |
| **Complexidade** | Trivial |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Dual series** — array de 2+ objetos em `series`
2. **Formatter `pt-BR`** no yaxis e tooltip — valores em R$
3. **Cores semânticas:** verde (bom — receita), vermelho (ruim — inadimplência)
4. **`curve: 'smooth'`** para linhas curvas bonitas
5. **`zoom: false`** — desabilitar zoom (usuário não precisa, mantém simples)
6. **Legend no topo** — identifica cada série
