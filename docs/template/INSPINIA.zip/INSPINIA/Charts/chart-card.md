# Chart Card (Wrapper ApexCharts)

**Categoria:** Chart wrapper
**Origem Inspinia:** `resources/views/charts/apex/*.blade.php` (padrão comum)
**Plugins JS:** ApexCharts 5.3.5
**Plugins CSS:** ApexCharts CSS + `.card` do Inspinia

---

## Descrição

Wrapper Blade que envolve um gráfico ApexCharts em um `card` com título e slots para filtros. Padroniza a moldura visual dos 4 gráficos que o ArtFinal usa (bar, line, column, pie). O chart em si é inicializado via Livewire component filho que dispatcha configs para ApexCharts.

> **Padrão:** cada tipo de gráfico é um **Livewire component** que recebe dados do PHP, renderiza o `<div id="...">` e emite evento JS com a config — mantém os dados no servidor e o render no cliente.

---

## Código Original (Inspinia — essência)

```html
<div class="card">
    <div class="card-header">
        <h4 class="card-title">Receita por Mês</h4>
    </div>
    <div class="card-body">
        <div dir="ltr">
            <div class="apex-charts" id="grafico-receita"></div>
        </div>
    </div>
</div>
```

```js
// resources/js/pages/chart-apex-bar.js
const options = {
    chart: { type: 'bar', height: 350 },
    series: [{ name: 'Receita', data: [12000, 15000, 18000, ...] }],
    xaxis: { categories: ['Jan', 'Fev', 'Mar', ...] },
}
new ApexCharts(document.querySelector('#grafico-receita'), options).render()
```

---

## Componente Blade Proposto

**Nome:** `<x-admin.chart-card>`
**Arquivo:** `resources/views/components/admin/chart-card.blade.php`

### Props

| Prop | Tipo | Default | Descrição |
|------|------|---------|-----------|
| `title` | `string` | — | Título do card |
| `chartId` | `string` | auto | ID único do `<div>` do gráfico |
| `height` | `int` | `350` | Altura em px |

### Slots

- `$headerActions` — filtros no header (ex: select de período)
- `$slot` — opcional — só necessário se quiser texto adicional. Normalmente o chart sozinho é suficiente

### Código

```blade
{{-- resources/views/components/admin/chart-card.blade.php --}}
@props([
    'title',
    'chartId' => 'chart-' . \Illuminate\Support\Str::random(6),
    'height' => 350,
])

<div {{ $attributes->class(['card']) }}>
    <div class="card-header">
        <h4 class="card-title">{{ $title }}</h4>
        @isset($headerActions)
            <div class="ms-auto flex gap-2">
                {{ $headerActions }}
            </div>
        @endisset
    </div>
    <div class="card-body">
        <div dir="ltr">
            <div class="apex-charts"
                 id="{{ $chartId }}"
                 style="min-height: {{ $height }}px"
                 wire:ignore>
            </div>
        </div>
        {{ $slot }}
    </div>
</div>
```

---

## Exemplo de Uso

```blade
<x-admin.chart-card title="Adesões por Mês" chart-id="grafico-adesoes" :height="320">
    <x-slot:headerActions>
        <x-shared.select name="contrato_filter" :options="$contratos" wire:model.live="filtroContrato" />
    </x-slot:headerActions>

    <livewire:admin.dashboard.grafico-adesoes chart-id="grafico-adesoes" :filtro="$filtroContrato" />
</x-admin.chart-card>
```

---

## Padrão Livewire para gráficos

```php
// app/Livewire/Admin/Dashboard/GraficoAdesoes.php
class GraficoAdesoes extends Component
{
    public string $chartId;
    public ?int $filtro = null;

    #[Computed]
    public function dados(): array
    {
        $meses = collect(range(11, 0))->map(fn($i) => now()->subMonths($i));
        $series = $meses->map(fn($m) => Adesao::whereYear('created_at', $m->year)
            ->whereMonth('created_at', $m->month)
            ->when($this->filtro, fn($q) => $q->where('contrato_id', $this->filtro))
            ->count())
            ->toArray();

        return [
            'categories' => $meses->map->format('M/y')->toArray(),
            'series' => [['name' => 'Adesões', 'data' => $series]],
        ];
    }

    public function render()
    {
        $this->dispatch('chart-update', chartId: $this->chartId, data: $this->dados);
        return view('livewire.admin.dashboard.grafico-adesoes');
    }
}
```

```blade
{{-- resources/views/livewire/admin/dashboard/grafico-adesoes.blade.php --}}
<div></div>
```

---

## Bridge JavaScript global

```js
// resources/js/admin/charts.js
import ApexCharts from 'apexcharts'

const charts = new Map()

function createOrUpdate(chartId, data, type = 'bar') {
    const el = document.getElementById(chartId)
    if (!el) return

    const config = {
        chart: { type, height: el.offsetHeight || 320, toolbar: { show: false } },
        series: data.series,
        xaxis: { categories: data.categories },
        colors: ['#5B73E8'],
        dataLabels: { enabled: false },
    }

    if (charts.has(chartId)) {
        charts.get(chartId).updateOptions(config)
    } else {
        const chart = new ApexCharts(el, config)
        chart.render()
        charts.set(chartId, chart)
    }
}

document.addEventListener('livewire:init', () => {
    Livewire.on('chart-update', ({ chartId, data, type }) => {
        createOrUpdate(chartId, data, type)
    })
})
```

---

## Mapeamento no PRD

| Tela | Gráfico | Tipo |
|------|--------|:----:|
| 14.2 Dashboard | Adesões por mês (12 meses) | bar |
| 14.2 Dashboard | Receita x Inadimplência (12 meses, linhas duplas) | line |
| 14.17 Relatórios | Receita por contrato | column |
| 14.17 Relatórios | Distribuição modalidade | pie |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P3 (Onda 4) |
| **Complexidade** | Média (bridge Livewire + ApexCharts) |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **`wire:ignore`** no `<div>` do gráfico — ApexCharts manipula o DOM, Livewire não deve re-renderizar
2. **ID único** por gráfico — o ApexCharts mantém instância em `Map` por ID
3. **Update via evento** — `chart-update` dispatch do Livewire atualiza os dados sem recriar o gráfico
4. **Cores padronizadas** — mesma paleta em todos os charts (`#5B73E8` primary, `#10B981` success, `#F59E0B` warning, `#EF4444` danger)
5. **`toolbar: false`** — remove toolbar do ApexCharts (download, zoom, etc.), UX mais limpo
6. **Responsive via `chart.height`** — usa altura do container
