# Toast

**Categoria:** Feedback
**Origem Inspinia:** `resources/views/ui/notifications.blade.php` (Inspinia usa "notifications" como nome, mas é toast)
**Plugins JS:** Preline 4.0.1 (`data-hs-remove-element` para dismiss)
**Plugins CSS:** Classes `hs-removing:*` + Tailwind

---

## Descrição

Notificação efêmera exibida em canto fixo da tela, com auto-dismiss opcional. Diferente de `<x-shared.alert>` (que fica no fluxo da página), o toast é **flutuante** e temporário. Usado para feedback de ação (salvou, excluiu, erro ao processar). No Portal ArtFinal, será disparado via Livewire events ou session flash.

---

## Código Original (Inspinia — essência)

```html
<div id="toast-1"
     role="alert"
     tabindex="-1"
     class="hs-removing:translate-x-5 hs-removing:opacity-0 bg-default-100 border-default-300 max-w-xs rounded-md border shadow transition duration-300">
    <div class="border-default-300 flex items-center border-b px-3 py-2">
        <p class="text-default-600 flex items-center gap-1.5 text-sm">
            <img class="size-4" src="/images/logo-sm.png" />
            <strong class="me-auto font-semibold">BRAND</strong>
        </p>
        <div class="ms-auto flex items-center gap-2">
            <span class="text-default-400 text-xs">agora</span>
            <button type="button"
                    class="flex items-center justify-center opacity-50 hover:opacity-100"
                    aria-label="Close"
                    data-hs-remove-element="#toast-1">
                <i class="iconify tabler--x text-default-800 size-6"></i>
            </button>
        </div>
    </div>
    <div class="p-3 text-sm">Contrato criado com sucesso!</div>
</div>
```

> O Inspinia **não fornece container de posicionamento nem auto-dismiss** — apenas o markup de toast individual. Precisamos agregar isso no componente Blade.

---

## Componente Blade Proposto

**Nome:** `<x-shared.toast-container>` (container fixo, inclui no layout) + `<x-shared.toast>` (toast individual)
**Arquivos:**
- `resources/views/components/shared/toast-container.blade.php`
- `resources/views/components/shared/toast.blade.php`

### `<x-shared.toast-container>` — Props

Nenhuma. É placeholder do container fixo no layout.

### Código do container

```blade
{{-- resources/views/components/shared/toast-container.blade.php --}}
<div class="fixed top-4 end-4 z-[100] flex flex-col gap-2 max-w-sm"
     x-data="{
         toasts: [],
         push(payload) {
             const id = 'toast-' + Date.now() + '-' + Math.random().toString(36).slice(2, 6)
             this.toasts.push({ id, ...payload })
             if (payload.duration !== false) {
                 setTimeout(() => this.remove(id), payload.duration || 4000)
             }
         },
         remove(id) {
             this.toasts = this.toasts.filter(t => t.id !== id)
         }
     }"
     x-on:toast.window="push($event.detail)">

    <template x-for="toast in toasts" :key="toast.id">
        <div :id="toast.id"
             role="alert"
             x-transition:enter="transition ease-out duration-300"
             x-transition:enter-start="opacity-0 translate-x-5"
             x-transition:enter-end="opacity-100 translate-x-0"
             x-transition:leave="transition ease-in duration-200"
             x-transition:leave-start="opacity-100"
             x-transition:leave-end="opacity-0 translate-x-5"
             :class="{
                 'bg-success/10 border-success text-success': toast.variant === 'success',
                 'bg-danger/10 border-danger text-danger': toast.variant === 'danger',
                 'bg-warning/10 border-warning text-warning': toast.variant === 'warning',
                 'bg-info/10 border-info text-info': toast.variant === 'info',
                 'bg-default-100 border-default-300 text-default-800': !toast.variant || toast.variant === 'default',
             }"
             class="border rounded-md shadow transition duration-300 w-80">
            <div class="flex items-start gap-3 p-3">
                <i class="iconify shrink-0 text-xl"
                   :class="{
                       'tabler--circle-check': toast.variant === 'success',
                       'tabler--alert-octagon': toast.variant === 'danger',
                       'tabler--alert-triangle': toast.variant === 'warning',
                       'tabler--info-circle': toast.variant === 'info' || !toast.variant,
                   }"></i>
                <div class="grow text-sm">
                    <strong x-show="toast.title" x-text="toast.title" class="block font-semibold"></strong>
                    <span x-text="toast.message"></span>
                </div>
                <button type="button"
                        class="shrink-0 opacity-50 hover:opacity-100"
                        @click="remove(toast.id)"
                        aria-label="Fechar">
                    <i class="iconify tabler--x size-5"></i>
                </button>
            </div>
        </div>
    </template>
</div>
```

O container escuta `window.dispatchEvent(new CustomEvent('toast', { detail: {...} }))` — padrão reusável para disparar a partir de qualquer componente Livewire ou JS.

---

## Exemplos de Uso

### Incluir o container no layout (uma vez)

```blade
{{-- resources/views/components/admin/layout.blade.php --}}
<body>
    <div class="wrapper">
        {{-- sidebar, topbar, content --}}
    </div>
    <x-shared.toast-container />
    @livewireScripts
</body>
```

### Disparar a partir de Livewire

```php
// app/Livewire/Admin/Contratos/Form.php
class Form extends Component
{
    public function save(): void
    {
        app(UpdateContratoAction::class)->execute(...);

        $this->dispatch('toast',
            variant: 'success',
            title: 'Contrato atualizado',
            message: 'As alterações foram salvas com sucesso.',
            duration: 4000,
        );
    }
}
```

### Disparar a partir de JS puro

```js
window.dispatchEvent(new CustomEvent('toast', {
    detail: {
        variant: 'danger',
        message: 'Erro ao sincronizar com o gateway',
    }
}))
```

### Session flash → toast

```blade
{{-- dentro de admin/layout.blade.php, antes do toast-container --}}
@if(session('success'))
    <script>
        window.addEventListener('DOMContentLoaded', () => {
            window.dispatchEvent(new CustomEvent('toast', {
                detail: { variant: 'success', message: @json(session('success')) }
            }))
        })
    </script>
@endif

@if(session('error'))
    <script>
        window.addEventListener('DOMContentLoaded', () => {
            window.dispatchEvent(new CustomEvent('toast', {
                detail: { variant: 'danger', message: @json(session('error')) }
            }))
        })
    </script>
@endif
```

---

## Quando Usar ✅

- Feedback imediato após ação Livewire (salvou, excluiu, aplicou reajuste)
- Notificações push do servidor via Laravel Echo + Livewire
- Session flash após `redirect()->route(...)->with('success', '...')`

## Quando NÃO Usar ❌

- Mensagens que o usuário precisa ler com calma → usar `<x-shared.alert>` dentro da página
- Confirmação antes de ação destrutiva → usar `<x-shared.confirm-dialog>` (SweetAlert)
- Validação de campo → usar `@error` no `<x-shared.input>`

---

## Mapeamento no PRD

| Tela | Seção PRD | Uso |
|------|-----------|-----|
| 14.1 Login Admin | 14.1 | Toast vermelho "Credenciais inválidas" |
| 14.3–14.20 | — | Toast após salvar/excluir (flash session) |
| 14.4 Tab 5 Reajustes | 14.4 | Toast "Reajuste aplicado com sucesso" |
| 14.12 Tab 5 Ações de parcela | 14.12 | Toast após baixa manual, reemissão, cancelamento |
| 14.13 Baixa em Lote | 14.13 | Toast "N parcelas baixadas" |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim (padrão de feedback universal) |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Média (Alpine + listener de evento) |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Container fixed** posicionado top-right por padrão — pode ser configurado via prop futura (top-left, bottom-right)
2. **Alpine.js necessário** — diferente do Inspinia que usa Preline + IDs estáticos, queremos sistema dinâmico com múltiplos toasts. Alpine é o caminho certo
3. **Auto-dismiss com `setTimeout`** — configurável via `duration` (ms). Passar `duration: false` desabilita auto-dismiss
4. **Event name padrão:** `toast` (sem prefixo). Padronizar para Livewire e JS puro
5. **Z-index `z-[100]`** — acima de modais normais. Se modais precisarem subir, ajustar proporcionalmente
6. **`x-transition`** — transição slide-in da direita + fade-out. Combina com o `hs-removing` do Inspinia mas é mais controlado
7. **Variantes default + success/danger/warning/info** — sem 8 variantes como button/badge. Toasts precisam ser claros
8. **Session flash auto-conversão:** o script inline no layout dispara o toast uma vez ao carregar. Manter esse bridge para MVP rápido
