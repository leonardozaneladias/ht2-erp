# Drawer (Offcanvas)

**Categoria:** UI
**Origem Inspinia:** `resources/views/ui/offcanvas.blade.php`
**Plugins JS:** Preline 4.0.1 (`hs-overlay`, `data-hs-overlay`)
**Plugins CSS:** Classes `hs-overlay-open:*` do Preline

---

## Descrição

Painel lateral deslizante para formulários rápidos, filtros avançados e previews. Ocupa lateral da tela (normalmente direita), com backdrop e scroll lock no body. Diferente de `<x-shared.modal>` (centralizado), drawer é **lateral** e mantém contexto da página visível atrás. Suporta 4 posições (start, end, top, bottom), scroll opcional no body, backdrop opcional.

---

## Código Original (Inspinia — essência)

```html
<!-- Botão que abre -->
<button type="button"
        class="btn bg-primary text-white"
        data-hs-overlay="#drawer-contrato"
        aria-controls="drawer-contrato"
        aria-expanded="false">
    Abrir Drawer
</button>

<!-- O drawer -->
<div id="drawer-contrato"
     class="hs-overlay hs-overlay-open:translate-x-0 bg-card border-default-300 fixed start-0 top-0 z-80 hidden h-full w-full max-w-sm -translate-x-full transform border-e transition-all duration-300"
     role="dialog"
     tabindex="-1"
     aria-labelledby="drawer-contrato-label">
    <div class="flex items-center justify-between p-5 border-b">
        <h3 id="drawer-contrato-label">Título</h3>
        <button type="button" data-hs-overlay="#drawer-contrato" aria-label="Close">
            <i class="iconify tabler--x text-xl"></i>
        </button>
    </div>
    <div class="p-5">
        Conteúdo do drawer
    </div>
</div>
```

### Variações de posição
- **Start (left, padrão):** `start-0 -translate-x-full` + `hs-overlay-open:translate-x-0`
- **End (right):** `end-0 translate-x-full` + `hs-overlay-open:translate-x-0`
- **Top:** `top-0 -translate-y-full h-auto w-full` + `hs-overlay-open:translate-y-0`
- **Bottom:** `bottom-0 translate-y-full h-auto w-full` + `hs-overlay-open:translate-y-0`

---

## Componente Blade Proposto

**Nome:** `<x-admin.drawer>`
**Arquivo:** `resources/views/components/admin/drawer.blade.php`
**Tipo:** Blade anônimo

### Props

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `id` | `string` | ✅ | — | ID único (usado por `data-hs-overlay="#id"`) |
| `title` | `?string` | ❌ | `null` | Título no header |
| `position` | `string` | ❌ | `'end'` | start, end, top, bottom |
| `size` | `string` | ❌ | `'md'` | sm (max-w-xs), md (max-w-sm), lg (max-w-md), xl (max-w-lg), full (max-w-full) |
| `bodyScroll` | `bool` | ❌ | `false` | Permitir scroll do body quando drawer aberto |
| `backdrop` | `bool` | ❌ | `true` | Mostrar overlay escuro atrás |

### Slots

| Slot | Descrição |
|------|-----------|
| `$slot` (default) | Conteúdo principal |
| `$footer` | Footer fixo no fim (botões de ação) |

### Código

```blade
{{-- resources/views/components/admin/drawer.blade.php --}}
@props([
    'id',
    'title' => null,
    'position' => 'end',
    'size' => 'md',
    'bodyScroll' => false,
    'backdrop' => true,
])

@php
    $sizeClass = match($size) {
        'sm' => 'max-w-xs',
        'lg' => 'max-w-md',
        'xl' => 'max-w-lg',
        'full' => 'max-w-full',
        default => 'max-w-sm',
    };

    $positionClasses = match($position) {
        'start' => 'start-0 top-0 h-full w-full -translate-x-full border-e',
        'top' => 'top-0 start-0 h-auto w-full -translate-y-full border-b',
        'bottom' => 'bottom-0 start-0 h-auto w-full translate-y-full border-t',
        default => 'end-0 top-0 h-full w-full translate-x-full border-s',  // end (right)
    };

    $optionalAttrs = collect([
        $bodyScroll ? '[--body-scroll:true]' : null,
        !$backdrop ? '[--overlay-backdrop:false]' : null,
    ])->filter()->join(' ');
@endphp

<div id="{{ $id }}"
     class="hs-overlay hs-overlay-open:translate-x-0 hs-overlay-open:translate-y-0 bg-card border-default-300 fixed z-80 hidden transform transition-all duration-300 {{ $positionClasses }} {{ $sizeClass }} {{ $optionalAttrs }}"
     role="dialog"
     tabindex="-1"
     aria-labelledby="{{ $id }}-label">

    <div class="flex h-full flex-col">
        @if($title)
            <div class="flex items-center justify-between p-5 border-b">
                <h3 id="{{ $id }}-label" class="font-semibold text-lg">{{ $title }}</h3>
                <button type="button"
                        data-hs-overlay="#{{ $id }}"
                        aria-label="Fechar"
                        class="opacity-60 hover:opacity-100">
                    <i class="iconify tabler--x text-xl"></i>
                </button>
            </div>
        @endif

        <div class="grow overflow-y-auto p-5">
            {{ $slot }}
        </div>

        @isset($footer)
            <div class="border-t p-5 shrink-0">
                {{ $footer }}
            </div>
        @endisset
    </div>
</div>
```

---

## Exemplos de Uso

### Abrir com botão simples

```blade
<x-shared.button data-hs-overlay="#drawer-categoria">
    Nova Categoria
</x-shared.button>

<x-admin.drawer id="drawer-categoria" title="Nova Categoria">
    <form wire:submit="salvar">
        <x-shared.input label="Nome" wire:model="nome" />
        <x-shared.textarea label="Descrição" wire:model="descricao" />
        <x-shared.toggle label="Ativo" wire:model="ativo" />

        <x-slot:footer>
            <div class="flex justify-end gap-2">
                <x-shared.button variant="default" style="outline" data-hs-overlay="#drawer-categoria">
                    Cancelar
                </x-shared.button>
                <x-shared.loading-button variant="primary" type="submit">
                    Salvar
                </x-shared.loading-button>
            </div>
        </x-slot:footer>
    </form>
</x-admin.drawer>
```

### Real (Drawer de Filtros Avançados 14.12)

```blade
<x-shared.button variant="default" style="outline" icon="tabler--filter" data-hs-overlay="#drawer-filtros">
    Filtros Avançados
</x-shared.button>

<x-admin.drawer id="drawer-filtros" title="Filtros Avançados" size="lg">
    <div class="space-y-4">
        <x-shared.select-search label="Contrato" wire:model.live="filtros.contrato_id" />
        <x-shared.select-search label="Curso" wire:model.live="filtros.curso_id" />
        <x-shared.select-search label="Período" wire:model.live="filtros.periodo_id" />
        <x-shared.date-range-picker label="Data Adesão" wire:model.live="filtros.data_adesao" />
        <x-shared.select label="Adimplência" wire:model.live="filtros.adimplencia">
            <option value="">Todos</option>
            <option value="em_dia">Em dia</option>
            <option value="inadimplente">Inadimplente</option>
        </x-shared.select>
    </div>

    <x-slot:footer>
        <div class="flex justify-between">
            <x-shared.button variant="default" style="ghost" wire:click="limparFiltros">
                Limpar
            </x-shared.button>
            <x-shared.button variant="primary" data-hs-overlay="#drawer-filtros">
                Aplicar
            </x-shared.button>
        </div>
    </x-slot:footer>
</x-admin.drawer>
```

---

## Quando Usar ✅

- Formulários curtos que não precisam de página dedicada (14.5 Categorias, 14.16 Índices)
- Filtros avançados que ocupam espaço demais inline
- Preview de detalhes sem sair da listagem
- Form rápido "Novo X" sem redirect

## Quando NÃO Usar ❌

- Formulários longos com múltiplas sections → usar página dedicada
- Alertas/confirmações → usar `<x-shared.modal>` ou `<x-shared.confirm-dialog>`
- Conteúdo efêmero → usar `<x-shared.toast>`

---

## Mapeamento no PRD

| Tela | Seção PRD | Uso |
|------|-----------|-----|
| Categorias | 14.5 | Drawer para CRUD rápido |
| Índices de Reajuste | 14.16 | Modal/drawer para CRUD |
| Usuários Admin | 14.18 | Form em drawer |
| Reajustes | 14.4 Tab 5 | Modal para novo reajuste — pode virar drawer |
| Formandos (filtros) | 14.12 | Filtros avançados em drawer |
| Parcelas (filtros) | 14.13 | Filtros em drawer |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Média (muitas posições, attributes Preline) |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Preline `data-hs-overlay`** obrigatório — tanto no trigger quanto no botão "Fechar"
2. **`z-80`** — acima da sidebar (z-40) e topbar (z-50). Cuidado com toasts (z-100)
3. **`[--body-scroll:true]`** permite scroll da página atrás — útil quando drawer não é crítico
4. **`[--overlay-backdrop:false]`** remove overlay escuro — drawer flutuando
5. **Position `start`/`end`** respeita RTL — em pt-BR `end` é direita
6. **Footer sticky** via `shrink-0` + `grow overflow-y-auto` no body para scroll interno correto
7. **Livewire + drawer:** ao fechar o drawer via `data-hs-overlay`, o componente Livewire não recebe evento automático. Para disparar reset, adicionar `x-on:hidden.overlay.hs="$wire.reset()"` no container
8. **Não confundir com modal** — modal é center + focus mode, drawer é lateral + contexto preservado
