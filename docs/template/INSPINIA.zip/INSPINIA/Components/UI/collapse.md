# Collapse

**Categoria:** UI
**Origem Inspinia:** `resources/views/ui/collapse.blade.php`
**Plugins JS:** Preline 4.0.1 (`hs-collapse-toggle`, `data-hs-collapse`)
**Plugins CSS:** Apenas Tailwind

---

## Descrição

Componente de collapse/expand controlado pelo Preline. Um botão com `data-hs-collapse="#id"` alterna a visibilidade de um container `.hs-collapse`. Suporta labels dinâmicos (ex: "Read more" / "Read less") via classes utilitárias `hs-collapse-open:hidden` e `hs-collapse-open:block`.

> Usado principalmente para **filtros collapsáveis** (14.12 Formandos, 14.13 Parcelas) e **descrições "Read more"** em textos longos.

---

## Código Original (Inspinia — essência)

```html
{{-- Botão --}}
<button class="hs-collapse-toggle btn bg-primary hover:bg-primary-hover text-white"
        data-hs-collapse="#collapseExample"
        aria-controls="collapseExample"
        aria-expanded="false">
    Collapse Button
</button>

{{-- Conteúdo --}}
<div id="collapseExample"
     class="hs-collapse hidden w-full overflow-hidden transition-[height] duration-300"
     aria-labelledby="collapseLink">
    <div class="card border border-dashed border-light card-body">
        Conteúdo que aparece/some ao clicar no botão acima.
    </div>
</div>
```

### Label dinâmico (Read more / Read less)

```html
<button class="hs-collapse-toggle ..." data-hs-collapse="#show-hide-collapse">
    <span class="hs-collapse-open:hidden">Read more</span>
    <span class="hs-collapse-open:block hidden">Read less</span>
    <i class="iconify tabler--chevron-up hs-collapse-open:rotate-180"></i>
</button>
```

---

## Componente Blade Proposto

**Nome:** `<x-shared.collapse>`
**Arquivo:** `resources/views/components/shared/collapse.blade.php`
**Tipo:** Blade anônimo

### Props

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `id` | `string` | ✅ | — | ID único do container |
| `open` | `bool` | ❌ | `false` | Se o collapse já deve vir aberto no primeiro render |

### Slots

| Slot | Descrição |
|------|-----------|
| `$trigger` | O botão/link que controla o collapse (opcional — pode ser externo) |
| `$slot` (default) | O conteúdo que aparece/some |

### Código

```blade
{{-- resources/views/components/shared/collapse.blade.php --}}
@props([
    'id',
    'open' => false,
])

@isset($trigger)
    <div>{{ $trigger }}</div>
@endisset

<div id="{{ $id }}"
     class="hs-collapse {{ $open ? 'open' : 'hidden' }} w-full overflow-hidden transition-[height] duration-300"
     {{ $attributes }}>
    {{ $slot }}
</div>
```

---

## Exemplos de Uso

### Básico com trigger interno

```blade
<x-shared.collapse id="detalhes-parcela">
    <x-slot:trigger>
        <button class="hs-collapse-toggle btn btn-ghost"
                data-hs-collapse="#detalhes-parcela"
                aria-controls="detalhes-parcela"
                aria-expanded="false">
            Ver detalhes
            <i class="iconify tabler--chevron-down hs-collapse-open:rotate-180 transition-transform"></i>
        </button>
    </x-slot:trigger>

    <div class="card border border-dashed card-body mt-2">
        <p>Histórico de tentativas de cobrança, boletos gerados, e-mails enviados.</p>
    </div>
</x-shared.collapse>
```

### Real (Portal ArtFinal — Filtros avançados 14.12)

```blade
<div class="mb-4">
    <button class="hs-collapse-toggle btn btn-secondary"
            data-hs-collapse="#filtros-formandos"
            aria-controls="filtros-formandos">
        <i class="iconify tabler--filter"></i> Filtros Avançados
        <i class="iconify tabler--chevron-down hs-collapse-open:rotate-180"></i>
    </button>
</div>

<x-shared.collapse id="filtros-formandos">
    <x-shared.card>
        <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
            <x-shared.select-search label="Contrato" wire:model.live="filtro.contrato_id" />
            <x-shared.select-search label="Curso" wire:model.live="filtro.curso_id" />
            <x-shared.select-search label="Período" wire:model.live="filtro.periodo_id" />
            <x-shared.date-range-picker label="Data Adesão" wire:model.live="filtro.data_adesao" />
            <x-shared.select label="Adimplência" wire:model.live="filtro.adimplencia">
                <option value="">Todos</option>
                <option value="em_dia">Em dia</option>
                <option value="inadimplente">Inadimplente</option>
            </x-shared.select>
        </div>
    </x-shared.card>
</x-shared.collapse>
```

---

## Quando Usar ✅

- Filtros avançados colapsáveis (14.12, 14.13)
- Seções de "Detalhes" ou "Ver mais" em cards
- Descrições longas que precisam ocultar/mostrar

## Quando NÃO Usar ❌

- Menus de navegação → usar accordion (`<x-shared.accordion>`) que agrupa múltiplos
- Modais → usar `<x-shared.modal>`
- Drawers laterais → usar `<x-admin.drawer>`

---

## Mapeamento no PRD

| Tela | Seção PRD | Uso |
|------|-----------|-----|
| Gestão Formandos (filtros) | 14.12 | Filtros avançados colapsáveis |
| Gestão Financeira (filtros) | 14.13 | Filtros collapsáveis no topo |
| Ficha Formando (detalhes auditoria) | 14.12 Tab 7 | Expandir JSON before/after |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Simples |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Preline obrigatório** — usa `hs-collapse-toggle`, `data-hs-collapse`, `.hs-collapse.open`. Não tentar reimplementar com Alpine quando já temos Preline
2. **`aria-expanded` no trigger** — o Preline atualiza automaticamente, mas começar em `"false"` ou `"true"` coerente com `open`
3. **`id` único obrigatório** — se instanciar múltiplos na mesma página, garantir IDs distintos
4. **Não confundir com accordion** — este é 1 container on/off. Accordion agrupa múltiplos (apenas um aberto por vez)
