# Badge

**Categoria:** UI
**Origem Inspinia:** `resources/views/ui/badges.blade.php`
**Plugins JS:** Nenhum
**Plugins CSS:** Apenas Tailwind

---

## Descrição

Pequeno chip colorido para exibir status, contagem ou tag. 8 variantes de cor (primary, secondary, success, danger, warning, info, light, dark) com 2 intensidades (soft `bg/15 text` e solid `bg text-white`), 3 formatos (retângulo `rounded`, pill `rounded-full`, square `rounded-none`), e 3 tamanhos (sm, md, lg). Opção de ícone.

> **Relacionado:** `<x-shared.status-badge>` (ver `status-badge.md`) é uma especialização que recebe um Enum e escolhe cor/label automaticamente.

---

## Código Original (Inspinia — essência)

```html
<!-- Soft -->
<span class="bg-primary/15 text-primary rounded px-2 py-0.5 text-xs font-semibold">Primary</span>

<!-- Solid -->
<span class="bg-success text-white rounded px-2 py-0.5 text-xs font-semibold">Success</span>

<!-- Pill -->
<span class="bg-warning/15 text-warning rounded-full px-2.5 py-0.5 text-xs font-semibold">Warning</span>

<!-- Com ícone -->
<span class="bg-info/15 text-info rounded-full px-2 py-0.5 text-xs font-semibold inline-flex items-center gap-1">
    <i class="iconify tabler--info-circle text-sm"></i>
    Info
</span>

<!-- Contador -->
<span class="relative inline-block">
    <button class="btn">Notifications</button>
    <span class="absolute top-0 end-0 translate-x-1/2 -translate-y-1/2 bg-danger text-white rounded-full size-4 text-xs flex items-center justify-center">
        3
    </span>
</span>
```

---

## Componente Blade Proposto

**Nome:** `<x-shared.badge>`
**Arquivo:** `resources/views/components/shared/badge.blade.php`
**Tipo:** Blade anônimo

### Props

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `variant` | `string` | ❌ | `'primary'` | 8 variantes de cor |
| `solid` | `bool` | ❌ | `false` | Fundo sólido em vez de soft |
| `pill` | `bool` | ❌ | `false` | Formato pill (rounded-full) |
| `size` | `string` | ❌ | `'md'` | sm, md, lg |
| `icon` | `?string` | ❌ | `null` | Ícone Iconify à esquerda |

### Código

```blade
{{-- resources/views/components/shared/badge.blade.php --}}
@props([
    'variant' => 'primary',
    'solid' => false,
    'pill' => false,
    'size' => 'md',
    'icon' => null,
])

@php
    $bgText = $solid
        ? "bg-{$variant} text-white"
        : "bg-{$variant}/15 text-{$variant}";

    $sizeClass = match($size) {
        'sm' => 'px-1.5 py-0 text-[10px]',
        'lg' => 'px-3 py-1 text-sm',
        default => 'px-2 py-0.5 text-xs',
    };

    $radiusClass = $pill ? 'rounded-full' : 'rounded';
@endphp

<span {{ $attributes->class([
    $bgText,
    $sizeClass,
    $radiusClass,
    'font-semibold inline-flex items-center gap-1 whitespace-nowrap'
]) }}>
    @if($icon)
        <i class="iconify {{ $icon }} text-sm"></i>
    @endif
    {{ $slot }}
</span>
```

---

## Exemplos de Uso

### Básico

```blade
<x-shared.badge variant="success">Ativo</x-shared.badge>
<x-shared.badge variant="danger" solid>Cancelado</x-shared.badge>
<x-shared.badge variant="warning" pill icon="tabler--clock">Pendente</x-shared.badge>
<x-shared.badge variant="info" size="sm">Novo</x-shared.badge>
```

### Real (Tabela de formandos 14.12)

```blade
<td>
    <x-shared.badge :variant="$formando->adimplente ? 'success' : 'danger'" pill>
        {{ $formando->adimplente ? 'Em dia' : 'Inadimplente' }}
    </x-shared.badge>
</td>
```

### Real (Badge de contagem no sidebar)

```blade
<li class="menu-item relative">
    <a class="menu-link" href="{{ route('admin.financeiro.parcelas.index', ['status' => 'vencido']) }}">
        <span class="menu-icon"><i class="iconify tabler--alert-triangle"></i></span>
        <span class="menu-text">Parcelas Vencidas</span>
        @if($contadorVencidas > 0)
            <x-shared.badge variant="danger" pill size="sm" solid class="ms-auto">
                {{ $contadorVencidas }}
            </x-shared.badge>
        @endif
    </a>
</li>
```

---

## Quando Usar ✅

- Status de linha em tabela (14.3, 14.4, 14.6, 14.12, 14.13)
- Contador de notificações (ver `topbar.md`)
- Tags/categorias (ex: "Grupo Exclusivo" em produtos)
- Badges de programação ("ATIVA", "FUTURA", "EXPIRADA" — 14.7)

## Quando NÃO Usar ❌

- Botão clicável → usar `<x-shared.button>` variant "ghost" small
- Alerta de página inteira → usar `<x-shared.alert>`
- Quando precisa de Enum-driven color → usar `<x-shared.status-badge>`

---

## Mapeamento no PRD

| Tela | Seção PRD | Uso |
|------|-----------|-----|
| Instituições | 14.3 | Badge Ativo/Inativo, contagem contratos |
| Contratos | 14.4 | Status (ativo/cancelado/concluído) |
| Produtos | 14.6 | "Grupo Exclusivo", "Disponível Adesão" |
| Programações | 14.7 | "ATIVA"/"FUTURA"/"EXPIRADA" |
| Condições | 14.8 | Modalidade (Boleto/Cartão/PIX) |
| Formandos | 14.12 | Adimplência (Em dia/Inadimplente) |
| Parcelas | 14.12 Tab 5, 14.13 | Status (Pendente/Pago/Vencido/Cancelado) + Modalidade |
| Termos | 14.11 | Versão |
| Topbar | — | Contador de notificações |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim (extremamente recorrente) |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Trivial |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Safelist Tailwind 4:** classes de cor dinâmicas (`bg-primary/15`, `text-primary`, `bg-success`, etc.) precisam estar no safelist — safelist compartilhado com alert, button, progress
2. **`whitespace-nowrap`** — badges não quebram linha mesmo em células estreitas
3. **`inline-flex items-center gap-1`** — necessário para alinhar ícone + texto. Aplicado sempre, mesmo sem ícone (sem custo visual)
4. **Contador como slot:** para badges com número, usar diretamente `{{ $count }}` no slot (sem formatação especial). Para valores grandes (>99), truncar na view: `{{ $count > 99 ? '99+' : $count }}`
5. **Não suportar `href`** — badges não são clicáveis por design. Se precisar clicável, envolver: `<a><x-shared.badge>...</x-shared.badge></a>`
