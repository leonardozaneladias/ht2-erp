# Tabs

**Categoria:** UI
**Origem Inspinia:** `resources/views/ui/tabs.blade.php`
**Plugins JS:** Preline 4.0.1 (`data-hs-tab`, `hs-tab-active:*`)
**Plugins CSS:** Classes `hs-tab-active:*` do Preline

---

## Descrição

Navegação por abas horizontais. Crítico no Portal ArtFinal — usado em **14.4 Contratos (5 tabs)**, **14.6 Produtos (5 tabs)**, e **14.12 Ficha Formando (7 tabs)**. Preline cuida do toggle de visibilidade dos panels via classes dinâmicas.

---

## Código Original (Inspinia — essência)

```html
<nav aria-label="Tabs" class="flex flex-wrap" role="tablist">
    <button type="button" role="tab"
            id="tab-overview"
            data-hs-tab="#panel-overview"
            aria-controls="panel-overview"
            aria-selected="true"
            class="hs-tab-active:border-b-transparent hs-tab-active:bg-card hs-tab-active:border hs-tab-active:text-primary border-default-300 hover:text-primary inline-flex items-center rounded-t border-b px-4 py-2 font-medium active">
        Overview
    </button>
    <button type="button" role="tab"
            id="tab-activity"
            data-hs-tab="#panel-activity"
            aria-controls="panel-activity"
            aria-selected="false"
            class="hs-tab-active:border-b-transparent hs-tab-active:bg-card hs-tab-active:border hs-tab-active:text-primary border-default-300 hover:text-primary inline-flex items-center rounded-t border-b px-4 py-2 font-medium">
        Activity
    </button>
</nav>

<div class="mt-5">
    <div id="panel-overview" role="tabpanel" aria-labelledby="tab-overview">
        <p>Conteúdo Overview (visível por padrão — sem `hidden`)</p>
    </div>
    <div id="panel-activity" role="tabpanel" aria-labelledby="tab-activity" class="hidden">
        <p>Conteúdo Activity (oculto por padrão)</p>
    </div>
</div>
```

**Variações:** justified (`w-full md:w-auto`), vertical, com ícones, pills, disabled.

---

## Componente Blade Proposto

**Nome:** `<x-shared.tabs>` + `<x-shared.tab>`
**Arquivos:**
- `resources/views/components/shared/tabs.blade.php` (container)
- `resources/views/components/shared/tab.blade.php` (single tab panel)

### Abordagem

Como tabs tem 2 partes (nav + panels) acoplados, vamos usar um padrão **array-driven**: as tabs são declaradas como prop `:tabs` no wrapper, e cada painel é um `<x-slot>` nomeado.

### Props — `tabs`

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `tabs` | `array` | ✅ | — | `[['id' => 'key', 'label' => 'X', 'icon' => 'tabler--...', 'disabled' => false]]` |
| `active` | `?string` | ❌ | primeiro | Key da tab ativa inicial |
| `justified` | `bool` | ❌ | `false` | Tabs distribuídas igualmente na largura |

### Código

```blade
{{-- resources/views/components/shared/tabs.blade.php --}}
@props([
    'tabs' => [],
    'active' => null,
    'justified' => false,
])

@php
    $activeKey = $active ?? ($tabs[0]['id'] ?? null);
@endphp

<div>
    <nav aria-label="Tabs" role="tablist"
         @class(['flex flex-wrap', 'md:flex-nowrap' => $justified])>
        @foreach($tabs as $tab)
            @php
                $isActive = $tab['id'] === $activeKey;
                $isDisabled = $tab['disabled'] ?? false;
            @endphp
            <button type="button"
                    role="tab"
                    id="tab-{{ $tab['id'] }}"
                    data-hs-tab="#panel-{{ $tab['id'] }}"
                    aria-controls="panel-{{ $tab['id'] }}"
                    aria-selected="{{ $isActive ? 'true' : 'false' }}"
                    @disabled($isDisabled)
                    @class([
                        'hs-tab-active:border-b-transparent hs-tab-active:bg-card hs-tab-active:border hs-tab-active:text-primary',
                        'border-default-300 hover:text-primary',
                        'inline-flex items-center gap-2 rounded-t border-b px-4 py-2 font-medium',
                        'focus:outline-hidden disabled:pointer-events-none disabled:opacity-50',
                        'active' => $isActive,
                        'w-auto md:w-full justify-center' => $justified,
                    ])>
                @if(!empty($tab['icon']))
                    <i class="iconify {{ $tab['icon'] }} text-base"></i>
                @endif
                {{ $tab['label'] }}
            </button>
        @endforeach
    </nav>

    <div class="mt-5">
        @foreach($tabs as $tab)
            @php $isActive = $tab['id'] === $activeKey; @endphp
            <div id="panel-{{ $tab['id'] }}"
                 role="tabpanel"
                 aria-labelledby="tab-{{ $tab['id'] }}"
                 @class(['hidden' => !$isActive])>
                {{ $$tab['id'] ?? '' }}  {{-- Acesso ao slot dinâmico por chave --}}
            </div>
        @endforeach
    </div>
</div>
```

> **Nota:** Blade não suporta acesso a slots dinâmicos via `$$key`. Abordagem alternativa: receber os panels como array de views renderizadas, OU declarar tabs hardcoded na view pai. Ver "Exemplo real" abaixo — é mais idiomático.

---

## Exemplo idiomático (sem componente wrapper, só padrão)

Dado que Blade não resolve slots dinâmicos bem, na prática usamos o padrão direto com helper visual. Criaremos **apenas** `<x-shared.tab-nav>` e `<x-shared.tab-panel>` como pequenos helpers que aplicam as classes corretas.

### `<x-shared.tab-nav>` (wrapper do nav)

```blade
{{-- resources/views/components/shared/tab-nav.blade.php --}}
@props(['justified' => false])

<nav aria-label="Tabs" role="tablist"
     @class(['flex flex-wrap', 'md:flex-nowrap' => $justified])>
    {{ $slot }}
</nav>
```

### `<x-shared.tab-trigger>` (button individual)

```blade
{{-- resources/views/components/shared/tab-trigger.blade.php --}}
@props([
    'id',
    'active' => false,
    'disabled' => false,
    'icon' => null,
    'justified' => false,
])

<button type="button"
        role="tab"
        id="tab-{{ $id }}"
        data-hs-tab="#panel-{{ $id }}"
        aria-controls="panel-{{ $id }}"
        aria-selected="{{ $active ? 'true' : 'false' }}"
        @disabled($disabled)
        @class([
            'hs-tab-active:border-b-transparent hs-tab-active:bg-card hs-tab-active:border hs-tab-active:text-primary',
            'border-default-300 hover:text-primary',
            'inline-flex items-center gap-2 rounded-t border-b px-4 py-2 font-medium',
            'focus:outline-hidden disabled:pointer-events-none disabled:opacity-50',
            'active' => $active,
            'w-auto md:w-full justify-center' => $justified,
        ])>
    @if($icon)<i class="iconify {{ $icon }} text-base"></i>@endif
    {{ $slot }}
</button>
```

### `<x-shared.tab-panel>` (painel de conteúdo)

```blade
{{-- resources/views/components/shared/tab-panel.blade.php --}}
@props(['id', 'active' => false])

<div id="panel-{{ $id }}"
     role="tabpanel"
     aria-labelledby="tab-{{ $id }}"
     @class(['hidden' => !$active])>
    {{ $slot }}
</div>
```

---

## Exemplos de Uso

### Real (Ficha Formando 14.12 — 7 tabs)

```blade
<x-shared.card>
    <x-shared.tab-nav>
        <x-shared.tab-trigger id="dados" active icon="tabler--user">Dados Pessoais</x-shared.tab-trigger>
        <x-shared.tab-trigger id="resp" icon="tabler--users">Responsáveis</x-shared.tab-trigger>
        <x-shared.tab-trigger id="portal" icon="tabler--device-laptop">Portal Users</x-shared.tab-trigger>
        <x-shared.tab-trigger id="pacotes" icon="tabler--package">Pacotes</x-shared.tab-trigger>
        <x-shared.tab-trigger id="extrato" icon="tabler--cash">Extrato</x-shared.tab-trigger>
        <x-shared.tab-trigger id="termos" icon="tabler--file-text">Termos</x-shared.tab-trigger>
        <x-shared.tab-trigger id="auditoria" icon="tabler--history">Histórico</x-shared.tab-trigger>
    </x-shared.tab-nav>

    <div class="mt-5">
        <x-shared.tab-panel id="dados" active>
            <livewire:admin.formandos.tabs.dados :formando="$formando" />
        </x-shared.tab-panel>
        <x-shared.tab-panel id="resp">
            <livewire:admin.formandos.tabs.responsaveis :formando="$formando" />
        </x-shared.tab-panel>
        <x-shared.tab-panel id="portal">
            <livewire:admin.formandos.tabs.portal-users :formando="$formando" />
        </x-shared.tab-panel>
        <x-shared.tab-panel id="pacotes">
            <livewire:admin.formandos.tabs.pacotes :formando="$formando" />
        </x-shared.tab-panel>
        <x-shared.tab-panel id="extrato">
            <livewire:admin.formandos.tabs.extrato :formando="$formando" />
        </x-shared.tab-panel>
        <x-shared.tab-panel id="termos">
            <livewire:admin.formandos.tabs.termos :formando="$formando" />
        </x-shared.tab-panel>
        <x-shared.tab-panel id="auditoria">
            <livewire:admin.formandos.tabs.auditoria :formando="$formando" />
        </x-shared.tab-panel>
    </div>
</x-shared.card>
```

---

## Quando Usar ✅

- Ficha do formando (7 tabs — 14.12)
- Form de contrato (5 tabs — 14.4)
- Form de produto (5 tabs — 14.6)
- Configurações agrupadas

## Quando NÃO Usar ❌

- Formulários longos com sections — usar `<x-shared.accordion>` (14.20 cadastro manual)
- Navegação por rota — usar sidebar
- Apenas 2 estados — usar toggle/switch

---

## Mapeamento no PRD

| Tela | Seção PRD | Tabs |
|------|-----------|------|
| Contrato form | 14.4 | 5 tabs (Dados, Responsáveis, Cursos, Períodos, Reajustes) |
| Produto form | 14.6 | 5 tabs (Dados, Programações, Condições, Descontos, Termos) |
| Ficha Formando | 14.12 | 7 tabs (Dados, Resp, Portal, Pacotes, Extrato, Termos, Auditoria) |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim (crítico para forms complexos) |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Média |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Abordagem split em 3 componentes** (tab-nav, tab-trigger, tab-panel) — mais idiomática que wrapper único, Blade não suporta slots dinâmicos
2. **Preline classes** — `hs-tab-active:*` aplicadas automaticamente quando aba ativa
3. **Classe `active`** inicial precisa coincidir com o painel **sem** `hidden`
4. **`aria-selected`**: início `"true"` na aba ativa, `"false"` nas demais. O Preline atualiza no click
5. **`disabled`** tabs pulam navegação automática pelo Preline
6. **Scroll horizontal em mobile:** se tabs excedem largura, adicionar `overflow-x-auto` no `<nav>`
7. **Livewire `wire:ignore`:** para preservar estado dos painéis entre re-renders, envolver o nav com `wire:ignore` — cuidado com isso
