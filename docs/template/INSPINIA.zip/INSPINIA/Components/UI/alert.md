# Alert

**Categoria:** UI
**Origem Inspinia:** `resources/views/ui/alerts.blade.php`
**Plugins JS:** Preline 4.0.1 (apenas se dismissible)
**Plugins CSS:** Apenas Tailwind

---

## Descrição

Banner colorido para mensagens informativas/de status dentro da página. Diferente de toast (ver `toast.md`), alert é **persistente** e fica no fluxo da página. Tem 8 variantes de cor (primary, secondary, success, danger, warning, info, light, dark), duas intensidades (`bg-{color}/15 text-{color}` soft, ou `bg-{color} text-white` solid), e opção de dismissível (X para fechar).

---

## Código Original (Inspinia — essência)

```html
<!-- Soft (variante padrão) -->
<div class="bg-primary/15 text-primary flex items-center rounded px-4 py-3" role="alert">
    This is a primary alert—something important you should know!
</div>

<!-- Solid -->
<div class="bg-success flex items-center rounded px-4 py-3 text-white" role="alert">
    Success! Your action was completed successfully.
</div>

<!-- Com link -->
<div class="bg-info/15 text-info flex items-center gap-1 rounded px-4 py-3" role="alert">
    Need more info? Check out
    <a class="font-bold" href="#">this info link</a>
    for important details.
</div>

<!-- Com ícone -->
<div class="bg-warning/15 text-warning flex items-center gap-2 rounded px-4 py-3" role="alert">
    <i class="iconify tabler--alert-triangle text-lg"></i>
    Warning! Please double-check your inputs.
</div>

<!-- Dismissible -->
<div class="bg-primary/15 text-primary flex items-center rounded px-4 py-3" id="dismiss-alert-1" role="alert">
    <span class="grow">Mensagem...</span>
    <button class="btn-close" data-hs-remove-element="#dismiss-alert-1">
        <i class="iconify tabler--x"></i>
    </button>
</div>
```

---

## Componente Blade Proposto

**Nome:** `<x-shared.alert>`
**Arquivo:** `resources/views/components/shared/alert.blade.php`
**Tipo:** Blade anônimo

### Props

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `variant` | `string` | ❌ | `'info'` | primary, secondary, success, danger, warning, info, light, dark |
| `solid` | `bool` | ❌ | `false` | Fundo sólido em vez de soft |
| `icon` | `?string` | ❌ | auto | Ícone Iconify. Se omitido, usa ícone padrão por variant |
| `dismissible` | `bool` | ❌ | `false` | Mostra botão X para fechar |
| `title` | `?string` | ❌ | `null` | Título opcional em negrito na primeira linha |

### Slots

- `$slot`: Conteúdo da mensagem (texto + links aceitos)

### Código

```blade
{{-- resources/views/components/shared/alert.blade.php --}}
@props([
    'variant' => 'info',
    'solid' => false,
    'icon' => null,
    'dismissible' => false,
    'title' => null,
])

@php
    $defaultIcons = [
        'primary' => 'tabler--info-circle',
        'secondary' => 'tabler--info-circle',
        'success' => 'tabler--circle-check',
        'danger' => 'tabler--alert-octagon',
        'warning' => 'tabler--alert-triangle',
        'info' => 'tabler--info-circle',
        'light' => 'tabler--info-circle',
        'dark' => 'tabler--info-circle',
    ];
    $iconClass = $icon ?? $defaultIcons[$variant] ?? 'tabler--info-circle';

    $bgText = $solid
        ? "bg-{$variant} text-white"
        : "bg-{$variant}/15 text-{$variant}";

    $id = 'alert-' . \Illuminate\Support\Str::random(6);
@endphp

<div id="{{ $id }}"
     class="{{ $bgText }} flex items-start gap-3 rounded px-4 py-3"
     role="alert">
    <i class="iconify {{ $iconClass }} text-xl shrink-0 mt-0.5"></i>
    <div class="grow">
        @if($title)
            <p class="font-bold">{{ $title }}</p>
        @endif
        <div>{{ $slot }}</div>
    </div>
    @if($dismissible)
        <button type="button"
                class="btn-close shrink-0"
                aria-label="Fechar"
                data-hs-remove-element="#{{ $id }}">
            <i class="iconify tabler--x"></i>
        </button>
    @endif
</div>
```

---

## Exemplos de Uso

### Básico

```blade
<x-shared.alert variant="success">
    Contrato criado com sucesso.
</x-shared.alert>

<x-shared.alert variant="warning" title="Atenção">
    Esta instituição possui 5 contratos vinculados.
</x-shared.alert>

<x-shared.alert variant="danger" dismissible>
    Erro ao processar pagamento. Tente novamente.
</x-shared.alert>
```

### Real (Dashboard 14.2 — Seção Alertas do Sistema)

```blade
@if($alertas->contratosSemProgramacao > 0)
    <x-shared.alert variant="warning" title="Contratos sem programação ativa">
        Existem <strong>{{ $alertas->contratosSemProgramacao }}</strong> contratos sem programação ativa.
        <a href="{{ route('admin.contratos.index', ['filter' => 'sem-programacao']) }}" class="font-bold">Revisar</a>
    </x-shared.alert>
@endif

@if($alertas->programacoesVencendo15Dias > 0)
    <x-shared.alert variant="info" title="Programações vencendo">
        <strong>{{ $alertas->programacoesVencendo15Dias }}</strong> programações vencem nos próximos 15 dias.
    </x-shared.alert>
@endif

@if($alertas->parcelasVencidas > 0)
    <x-shared.alert variant="danger" title="Parcelas vencidas sem tratamento">
        <strong>{{ $alertas->parcelasVencidas }}</strong> parcelas vencidas aguardando ação.
        <a href="{{ route('admin.financeiro.parcelas.index', ['status' => 'vencido']) }}" class="font-bold">Ver todas</a>
    </x-shared.alert>
@endif
```

---

## Quando Usar ✅

- Feedback persistente dentro de uma página (após uma ação)
- Alertas do sistema no dashboard (14.2)
- Avisos contextuais em formulários ("Esta ação é irreversível")
- Sessão flash messages (`session()->flash('success', '...')` renderizado como alert no topo)

## Quando NÃO Usar ❌

- Feedback efêmero de ação → usar `<x-shared.toast>` (aparece e some)
- Confirmação de ação destrutiva → usar `<x-shared.confirm-dialog>` (SweetAlert)
- Validação de campo → usar o erro do próprio `<x-shared.input>` via `@error`

---

## Mapeamento no PRD

| Tela | Seção PRD | Uso |
|------|-----------|-----|
| Dashboard | 14.2 | Seção "Alertas do Sistema" com 4 tipos de aviso |
| Contratos (form) | 14.4 | Alerta se mudar config de responsáveis "Com esta configuração..." |
| Programações (form) | 14.7 | Alerta de sobreposição de datas |
| Descontos (form) | 14.9 | Alerta de sobreposição |
| Configurações | 14.15 | Preview dinâmico das configs |
| Reajustes | 14.4 Tab 5 | Confirmação antes de aplicar |
| Qualquer view | session flash | Mensagens success/error após redirect |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Simples |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Safelist Tailwind 4:** as classes dinâmicas `bg-primary/15`, `text-primary`, `bg-success`, etc. precisam estar no safelist do `tailwind.config.js` OU dar safelist via `@source` no CSS. Sem isso, o purge remove essas classes e o componente quebra
2. **Ícone automático por variant** — `success` vira check, `warning` vira triangle, `danger` vira octagon. Pode ser sobrescrito via prop `icon`
3. **ID aleatório para dismissible** — usa `Str::random(6)` para evitar colisão se múltiplos alerts dismissíveis na mesma página
4. **`data-hs-remove-element`** é do Preline — remove o elemento do DOM ao clicar no X
5. **Flash messages:** criar helper `<x-shared.flash-alerts />` que itera `session()->get('success'|'error'|'warning')` e renderiza vários `<x-shared.alert>` — incluído no layout master
6. **Links dentro:** manter classe `font-bold` ou similar no `<a>` interno para destaque (sem isso ficam invisíveis no mesmo tom)
