# Breadcrumb

**Categoria:** UI
**Origem Inspinia:** `resources/views/ui/breadcrumb.blade.php`
**Plugins JS:** Nenhum
**Plugins CSS:** Apenas Tailwind + Iconify (tabler)

---

## Descrição

Navegação hierárquica horizontal mostrando o caminho até a página atual. Usa `<nav>` + `<ol>` semântico, com chevrons Iconify como divisores. Último item não é clicável e tem `aria-current="page"`.

> **Overlap com `<x-admin.page-header>`:** o page-header já inclui breadcrumb próprio à direita do título. Este componente é a versão **standalone** para casos isolados (ex: dentro de um card, drawer ou modal).

---

## Código Original (Inspinia — essência)

```html
<nav class="py-2.5">
    <ol class="flex items-center whitespace-nowrap">
        <li class="inline-flex items-center">
            <a class="text-default-600 hover:text-primary flex items-center font-medium" href="#">Home</a>
            <i class="iconify tabler--chevron-right text-default-400 m-0.75 text-base pe-1"></i>
        </li>
        <li class="inline-flex items-center">
            <a class="text-default-600 hover:text-primary flex items-center font-medium" href="#">Library</a>
            <i class="iconify tabler--chevron-right text-default-400 m-0.75 text-base pe-1"></i>
        </li>
        <li aria-current="page" class="text-default-400 inline-flex items-center truncate font-medium">
            Data
        </li>
    </ol>
</nav>
```

Variantes no template: com ícones nos crumbs, em card colored, com dividers alternativos (slash, dot).

---

## Componente Blade Proposto

**Nome:** `<x-shared.breadcrumb>`
**Arquivo:** `resources/views/components/shared/breadcrumb.blade.php`
**Tipo:** Blade anônimo

### Props

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `items` | `array` | ✅ | — | Lista de crumbs `[['label' => 'X', 'url' => '...', 'icon' => 'tabler--home']]` |
| `divider` | `string` | ❌ | `'tabler--chevron-right'` | Ícone Iconify usado como separador |

### Código

```blade
{{-- resources/views/components/shared/breadcrumb.blade.php --}}
@props([
    'items' => [],
    'divider' => 'tabler--chevron-right',
])

<nav class="py-2.5" aria-label="Breadcrumb">
    <ol class="flex items-center whitespace-nowrap">
        @foreach($items as $i => $item)
            @php $isLast = $i === count($items) - 1; @endphp

            @if($isLast)
                <li aria-current="page" class="text-default-400 inline-flex items-center truncate font-medium">
                    @if(!empty($item['icon']))
                        <i class="iconify {{ $item['icon'] }} me-1 text-sm"></i>
                    @endif
                    {{ $item['label'] }}
                </li>
            @else
                <li class="inline-flex items-center">
                    <a class="text-default-600 hover:text-primary flex items-center font-medium"
                       href="{{ $item['url'] ?? '#' }}">
                        @if(!empty($item['icon']))
                            <i class="iconify {{ $item['icon'] }} me-1 text-sm"></i>
                        @endif
                        {{ $item['label'] }}
                    </a>
                    <i class="iconify {{ $divider }} text-default-400 m-0.75 text-base pe-1 rtl:rotate-180"></i>
                </li>
            @endif
        @endforeach
    </ol>
</nav>
```

---

## Exemplos de Uso

### Básico

```blade
<x-shared.breadcrumb :items="[
    ['label' => 'Admin', 'url' => route('admin.dashboard'), 'icon' => 'tabler--home'],
    ['label' => 'Contratos', 'url' => route('admin.contratos.index')],
    ['label' => 'Editar'],
]" />
```

### Real (Portal ArtFinal — dentro de um card de ficha do formando)

```blade
<x-shared.card>
    <x-shared.breadcrumb :items="[
        ['label' => 'Formandos', 'url' => route('admin.formandos.index')],
        ['label' => $formando->contrato->codigo_turma, 'url' => route('admin.contratos.show', $formando->contrato)],
        ['label' => $formando->nome_completo],
    ]" />
    {{-- demais campos da ficha --}}
</x-shared.card>
```

---

## Quando Usar ✅

- Dentro de modais/drawers que precisem indicar contexto
- Em pages onde `<x-admin.page-header>` já tem outro breadcrumb customizado e você quer um secundário interno
- Em views que **não** usam o layout master (raro)

## Quando NÃO Usar ❌

- No topo de uma view usando `<x-admin.layout>` — o `<x-admin.page-header>` já cobre
- Para navegação horizontal tipo menu — use `<x-admin.sidebar>`
- Como linkagem contextual (ex: "ver também") — use link normal

---

## Mapeamento no PRD

| Tela | Seção PRD | Como É Usado |
|------|-----------|-------------|
| Todas via page-header | 14.* | Por tabela em `page-header.md` — este componente é complementar |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim (uso secundário) |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Simples |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Substituir a lista estática** por prop `items` array — o original é hardcoded no HTML
2. **Adicionar `rtl:rotate-180` no chevron** — suporte RTL futuro
3. **`aria-label="Breadcrumb"`** no `<nav>` — acessibilidade mínima
4. **`aria-current="page"`** no último item
5. **Fallback de `url`** para `#` quando ausente — evita erro Blade
