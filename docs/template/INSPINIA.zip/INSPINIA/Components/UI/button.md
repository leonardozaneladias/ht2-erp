# Button

**Categoria:** UI
**Origem Inspinia:** `resources/views/ui/buttons.blade.php`
**Plugins JS:** Nenhum (loading-button usa Ladda — ver `loading-button.md`)
**Plugins CSS:** Classe `.btn` do Inspinia

---

## Descrição

Botão base do sistema. 8 variantes de cor (primary, secondary, success, danger, warning, info, light, dark), 3 estilos (solid, outline, ghost), 3 tamanhos (sm, md, lg), opção de formato pill (`rounded-full`), icon-only e bloco (full-width).

---

## Código Original (Inspinia — essência)

```html
<!-- Solid -->
<button class="btn bg-primary hover:bg-primary-hover text-white" type="button">Primary</button>

<!-- Outline -->
<button class="btn border-primary text-primary hover:bg-primary hover:text-white" type="button">Primary</button>

<!-- Rounded (pill) -->
<button class="btn bg-primary hover:bg-primary-hover rounded-full text-white">Primary</button>

<!-- Default (cinza) -->
<button class="btn border-default-300" type="button">Default</button>

<!-- Icon button -->
<button class="btn btn-icon bg-primary text-white">
    <i class="iconify tabler--plus"></i>
</button>
```

Variantes completas no template: gradient, soft, block (w-full), disabled, com ícones à esquerda/direita.

---

## Componente Blade Proposto

**Nome:** `<x-shared.button>`
**Arquivo:** `resources/views/components/shared/button.blade.php`
**Tipo:** Blade anônimo

### Props

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `variant` | `string` | ❌ | `'primary'` | primary, secondary, success, danger, warning, info, light, dark, default |
| `style` | `string` | ❌ | `'solid'` | solid, outline, ghost |
| `size` | `string` | ❌ | `'md'` | sm, md, lg |
| `pill` | `bool` | ❌ | `false` | Formato arredondado total |
| `block` | `bool` | ❌ | `false` | Full-width |
| `icon` | `?string` | ❌ | `null` | Ícone à esquerda |
| `iconRight` | `?string` | ❌ | `null` | Ícone à direita |
| `iconOnly` | `bool` | ❌ | `false` | Botão só com ícone |
| `type` | `string` | ❌ | `'button'` | button, submit, reset |
| `href` | `?string` | ❌ | `null` | Se informado, renderiza `<a>` em vez de `<button>` |
| `disabled` | `bool` | ❌ | `false` | — |

### Código

```blade
{{-- resources/views/components/shared/button.blade.php --}}
@props([
    'variant' => 'primary',
    'style' => 'solid',
    'size' => 'md',
    'pill' => false,
    'block' => false,
    'icon' => null,
    'iconRight' => null,
    'iconOnly' => false,
    'type' => 'button',
    'href' => null,
    'disabled' => false,
])

@php
    // Cor: solid, outline ou ghost
    $variantClass = match($style) {
        'outline' => "border-{$variant} text-{$variant} hover:bg-{$variant} hover:text-white",
        'ghost' => "text-{$variant} hover:bg-{$variant}/10",
        default => $variant === 'default'
            ? 'border-default-300 text-default-700 hover:bg-light'
            : "bg-{$variant} hover:bg-{$variant}-hover text-white",
    };

    $sizeClass = match($size) {
        'sm' => 'btn-sm',
        'lg' => 'btn-lg',
        default => '',
    };

    $classes = collect([
        'btn',
        $variantClass,
        $sizeClass,
        $pill ? 'rounded-full' : null,
        $block ? 'w-full' : null,
        $iconOnly ? 'btn-icon' : null,
        'inline-flex items-center gap-1.5 justify-center',
    ])->filter()->join(' ');
@endphp

@if($href)
    <a href="{{ $disabled ? '#' : $href }}"
       {{ $attributes->class($classes) }}
       @if($disabled) aria-disabled="true" tabindex="-1" @endif>
        @if($icon)<i class="iconify {{ $icon }}"></i>@endif
        {{ $slot }}
        @if($iconRight)<i class="iconify {{ $iconRight }}"></i>@endif
    </a>
@else
    <button type="{{ $type }}"
            {{ $attributes->class($classes) }}
            @disabled($disabled)>
        @if($icon)<i class="iconify {{ $icon }}"></i>@endif
        {{ $slot }}
        @if($iconRight)<i class="iconify {{ $iconRight }}"></i>@endif
    </button>
@endif
```

---

## Exemplos de Uso

### Básico

```blade
<x-shared.button variant="primary">Salvar</x-shared.button>
<x-shared.button variant="danger" icon="tabler--trash">Excluir</x-shared.button>
<x-shared.button variant="default" style="outline">Cancelar</x-shared.button>
<x-shared.button variant="success" size="sm" pill>Aprovar</x-shared.button>
<x-shared.button variant="primary" icon-only icon="tabler--plus" />
```

### Real (Form de Contratos 14.4)

```blade
<div class="flex justify-end gap-2 mt-6">
    <x-shared.button variant="default" style="outline" :href="route('admin.contratos.index')">
        Cancelar
    </x-shared.button>
    <x-shared.loading-button variant="primary" type="submit" wire:target="salvar">
        Salvar Contrato
    </x-shared.loading-button>
</div>
```

### Real (Header de listagem)

```blade
<x-slot:actions>
    @can('contratos.criar')
        <x-shared.button variant="primary" icon="tabler--plus" :href="route('admin.contratos.create')">
            Novo Contrato
        </x-shared.button>
    @endcan
    @can('contratos.exportar')
        <x-shared.button variant="default" style="outline" icon="tabler--download" wire:click="exportarCsv">
            CSV
        </x-shared.button>
    @endcan
</x-slot:actions>
```

---

## Quando Usar ✅

- **Ações primárias/destrutivas** em forms, modais e headers
- **Navegação** via `href` (evita styling manual de `<a>`)
- **Icon buttons** em tabelas (editar, deletar, ver)

## Quando NÃO Usar ❌

- Links de texto inline → usar `<a>` com classe `text-primary`
- Botões de submit que precisam de loading → usar `<x-shared.loading-button>`
- Ações em dropdown → usar `.dropdown-item` dentro de `<x-shared.dropdown>`

---

## Mapeamento no PRD

Usado em **TODAS as 20 telas** do admin — é primitivo universal. Citações específicas:

| Tela | Uso |
|------|-----|
| 14.1 | "Entrar" (loading) |
| 14.2 | "Ver Ficha", "Ver Extrato" |
| 14.3–14.20 | "+ Novo X", "Cancelar", "Salvar", "Exportar" |
| 14.4 Tab 5 | "Aplicar Reajuste" (com confirmação) |
| 14.7 | "Adicionar Programação" |
| 14.10 | "Vincular Termo", "Preview PDF" |
| 14.11 | "Preview" |
| 14.13 | "Dar Baixa em Lote", "Exportar Selecionadas" |
| 14.19 | "Selecionar Todos" / "Limpar Todos" |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim (primitivo universal) |
| **Prioridade** | P1 (Onda 2) |
| **Complexidade** | Média (muitas props, mas código direto) |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Classe `.btn`** vem do CSS do Inspinia — copiar para `resources/css/admin.css`
2. **Hover colors (`bg-primary-hover`, etc.)** — definidas como CSS custom properties em `config/_root.css`. Manter
3. **Safelist dinâmica** para variant × style × size — adicionar ao `tailwind.config.js`
4. **`<a>` vs `<button>`:** o componente decide automaticamente via prop `href`. Uso correto: nav → `href`, ação (submit, click) → sem href
5. **`disabled` em `<a>`:** adiciona `aria-disabled="true"`, `tabindex="-1"`, e aponta `href="#"`. Visual é obrigação do CSS `.btn[aria-disabled="true"]`
6. **Tamanhos `btn-sm` e `btn-lg`** vêm do CSS do Inspinia — alternativa é usar `px-2 py-1 text-xs` e `px-6 py-3 text-lg` inline se não quiser copiar o CSS base
7. **`@disabled`** é diretiva Blade nativa (Laravel 11+)
8. **Ghost style** não existe no Inspinia original — é adição nossa. Classe: `text-{variant} hover:bg-{variant}/10`
