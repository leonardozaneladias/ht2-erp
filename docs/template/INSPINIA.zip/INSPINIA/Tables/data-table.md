# Data Table (DataTable unificada)

**Categoria:** Table
**Origem Inspinia:** `resources/views/tables/datatables/*.blade.php` (15 variantes consolidadas)
**Plugins JS:** DataTables.net 2.3.3 + plugins (buttons, export, checkbox-select, fixed-columns, fixed-header, responsive, keytable)
**Plugins CSS:** DataTables CSS + classe `.table` do Inspinia

---

## Descrição

**Tabela única consolidada** com todas as features do DataTables.net ativáveis via props: busca, export (CSV/Excel/PDF/Print), seleção múltipla, column search, range search, responsividade, etc. Em vez de 15 componentes separados (como os 15 showcases do Inspinia), criamos **um** `<x-admin.data-table>` rico em props.

> **Alternativa Livewire:** para tabelas < 500 linhas, considerar tabela pura Livewire com Alpine (mais leve, sem jQuery). Porém DataTables ainda é padrão para CRUDs grandes.

---

## Código Original (Inspinia — 15 variantes)

O Inspinia tem 15 arquivos showcase. Todos seguem o padrão:

```html
<table class="table table-bordered" id="datatable-basic">
    <thead>
        <tr>
            <th>ID</th>
            <th>Nome</th>
            <th>Status</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        {{-- rows --}}
    </tbody>
</table>
```

```js
$('#datatable-basic').DataTable({
    language: { url: '/datatables/pt-BR.json' },
    buttons: ['csv', 'excel', 'pdf', 'print'],
    dom: 'Bfrtip',
})
```

---

## Componente Blade Proposto

**Nome:** `<x-admin.data-table>`
**Arquivo:** `resources/views/components/admin/data-table.blade.php`
**Tipo:** Blade + class-based (para configuração complexa de DataTables)

### Props

| Prop | Tipo | Default | Descrição |
|------|------|---------|-----------|
| `id` | `string` | auto | ID único da tabela |
| `columns` | `array` | — | `[['label' => 'Nome', 'searchable' => true, 'orderable' => true]]` |
| `searchable` | `bool` | `true` | Busca global |
| `exportable` | `bool` | `false` | Botões CSV/Excel/PDF |
| `selectable` | `bool` | `false` | Checkbox de seleção múltipla |
| `columnSearch` | `bool` | `false` | Busca por coluna no header |
| `responsive` | `bool` | `true` | Responsive mode |
| `perPage` | `int` | `25` | Items por página |

### Código

```blade
{{-- resources/views/components/admin/data-table.blade.php --}}
@props([
    'id' => 'dt-' . \Illuminate\Support\Str::random(6),
    'columns' => [],
    'searchable' => true,
    'exportable' => false,
    'selectable' => false,
    'columnSearch' => false,
    'responsive' => true,
    'perPage' => 25,
])

<div wire:ignore>
    <table id="{{ $id }}"
           class="table table-bordered w-full"
           data-datatable="true"
           data-searchable="{{ $searchable ? 'true' : 'false' }}"
           data-exportable="{{ $exportable ? 'true' : 'false' }}"
           data-selectable="{{ $selectable ? 'true' : 'false' }}"
           data-column-search="{{ $columnSearch ? 'true' : 'false' }}"
           data-responsive="{{ $responsive ? 'true' : 'false' }}"
           data-per-page="{{ $perPage }}">
        <thead>
            <tr>
                @if($selectable)
                    <th class="w-4"><input type="checkbox" class="form-checkbox" data-select-all /></th>
                @endif
                @foreach($columns as $col)
                    <th
                        @if(($col['orderable'] ?? true) === false) data-orderable="false" @endif
                        @if(($col['searchable'] ?? true) === false) data-searchable="false" @endif>
                        {{ $col['label'] }}
                    </th>
                @endforeach
            </tr>
            @if($columnSearch)
                <tr class="column-search">
                    @if($selectable)<th></th>@endif
                    @foreach($columns as $col)
                        <th>
                            @if(($col['searchable'] ?? true) !== false)
                                <input type="text" class="form-input form-input-sm" placeholder="Filtrar..." />
                            @endif
                        </th>
                    @endforeach
                </tr>
            @endif
        </thead>
        <tbody>
            {{ $slot }}
        </tbody>
    </table>
</div>
```

---

## Exemplos de Uso

### Real (Listagem de Contratos 14.4)

```blade
<x-shared.card title="Todos os Contratos" :body-padding="false">
    <x-admin.data-table
        :columns="[
            ['label' => 'Código', 'searchable' => true],
            ['label' => 'Nome da Turma'],
            ['label' => 'Instituição'],
            ['label' => 'Conclusão'],
            ['label' => 'Meta', 'orderable' => false],
            ['label' => 'Aderidos', 'orderable' => false],
            ['label' => 'Status'],
            ['label' => 'Ações', 'orderable' => false, 'searchable' => false],
        ]"
        exportable
        column-search>

        @foreach($contratos as $contrato)
            <tr>
                <td>{{ $contrato->codigo_turma }}</td>
                <td>{{ $contrato->nome_turma }}</td>
                <td>{{ $contrato->instituicao->nome_fantasia }}</td>
                <td>{{ sprintf('%02d/%d', $contrato->mes_conclusao, $contrato->ano_conclusao) }}</td>
                <td>{{ $contrato->meta_formandos }}</td>
                <td>{{ $contrato->adesoes_ativas_count }}</td>
                <td><x-shared.status-badge :enum="$contrato->status" /></td>
                <td>
                    <x-shared.dropdown placement="bottom-end">
                        <x-slot:button>
                            <button class="hs-dropdown-toggle btn btn-icon btn-sm">
                                <i class="iconify tabler--dots-vertical"></i>
                            </button>
                        </x-slot:button>
                        <x-shared.dropdown-item icon="tabler--edit" :href="route('admin.contratos.edit', $contrato)">
                            Editar
                        </x-shared.dropdown-item>
                        <x-shared.dropdown-item icon="tabler--copy" wire:click="duplicar({{ $contrato->id }})">
                            Duplicar
                        </x-shared.dropdown-item>
                        <x-shared.dropdown-divider />
                        <x-shared.dropdown-item icon="tabler--ban" variant="danger"
                                                wire:click="confirmarInativacao({{ $contrato->id }})">
                            Inativar
                        </x-shared.dropdown-item>
                    </x-shared.dropdown>
                </td>
            </tr>
        @endforeach
    </x-admin.data-table>
</x-shared.card>
```

### Real (Parcelas com seleção 14.13)

```blade
<x-admin.data-table
    :columns="[
        ['label' => 'Formando'],
        ['label' => 'Contrato'],
        ['label' => 'Parcela'],
        ['label' => 'Valor'],
        ['label' => 'Vencimento'],
        ['label' => 'Status'],
        ['label' => 'Ações', 'orderable' => false],
    ]"
    selectable
    exportable>
    {{-- rows --}}
</x-admin.data-table>
```

---

## Init global JavaScript

```js
// resources/js/admin/data-table-init.js
import $ from 'jquery'
import 'datatables.net-dt'
import 'datatables.net-buttons-dt'
import 'datatables.net-buttons/js/buttons.html5'
import 'datatables.net-buttons/js/buttons.print'
import 'datatables.net-responsive-dt'
import 'datatables.net-select-dt'

export function initDataTables() {
    $('table[data-datatable="true"]').each(function() {
        const $t = $(this)
        const config = {
            language: { url: '/js/datatables/pt-BR.json' },
            pageLength: parseInt($t.data('per-page') || 25),
            responsive: $t.data('responsive') === true || $t.data('responsive') === 'true',
            searching: $t.data('searchable') !== false,
        }

        if ($t.data('exportable')) {
            config.dom = 'Blfrtip'
            config.buttons = ['csv', 'excel', 'print']
        }

        if ($t.data('selectable')) {
            config.select = { style: 'multi', selector: 'td:first-child' }
        }

        $t.DataTable(config)
    })
}

document.addEventListener('livewire:init', () => {
    initDataTables()
    Livewire.hook('morph.added', () => initDataTables())
})
```

---

## Mapeamento no PRD

Usado em **todas as telas de listagem** (14.3–14.13, 14.17, 14.18).

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim (crítico) |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Alta |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Componente único** em vez de 15 arquivos — props toggleam features
2. **`wire:ignore` no wrapper** — DataTables manipula DOM
3. **Re-init no `morph.added`** — Livewire re-renderiza, DataTables precisa re-inicializar
4. **Localização pt-BR** — arquivo em `public/js/datatables/pt-BR.json` (baixar de datatables.net/plug-ins/i18n)
5. **jQuery obrigatório** — DataTables.net 2.3 ainda depende de jQuery 3.7
6. **Export PDF:** requer `pdfmake` + `jszip` (já no package.json)
7. **Alternativa:** tabela pura Livewire + pagination custom (ver `pagination.md`) — menos features mas sem jQuery
8. **15 variantes consolidadas:** basic, ajax, export, select, javascript, rendering, scroll, fixed-columns, fixed-header, column-search, range-search, child-rows, rows-add, checkbox-select, show-hide-columns
