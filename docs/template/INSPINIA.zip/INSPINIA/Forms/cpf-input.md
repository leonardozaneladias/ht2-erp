# CPF Input

**Categoria:** Form (masked)
**Origem Inspinia:** `resources/views/form/other-plugin.blade.php` (Inputmask 5.0.9)
**Plugins JS:** Inputmask 5.0.9
**Plugins CSS:** Herda de `input.md`

---

## Descrição

Input especializado para CPF brasileiro com máscara automática `XXX.XXX.XXX-XX`, validação via `pt-br-validator` do Laravel Legends. Herda de `<x-shared.input>` adicionando `data-inputmask`.

---

## Componente Blade Proposto

**Nome:** `<x-shared.cpf-input>`
**Arquivo:** `resources/views/components/shared/cpf-input.blade.php`

### Props

Herda `name`, `label`, `hint`, `required` de `<x-shared.input>`.

### Código

```blade
{{-- resources/views/components/shared/cpf-input.blade.php --}}
@props([
    'name',
    'label' => 'CPF',
    'hint' => null,
    'required' => false,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4">
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <input id="{{ $name }}" name="{{ $name }}" type="text"
           data-inputmask="'mask': '999.999.999-99'"
           placeholder="000.000.000-00"
           {{ $attributes->class([
               'form-input font-mono',
               'border-danger!' => $hasError,
           ]) }}
           @required($required) />

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

```blade
<x-shared.cpf-input name="cpf" wire:model="formando.cpf" required />
<x-shared.cpf-input name="cpf_responsavel" label="CPF do Responsável" wire:model="responsavel.cpf" />
```

### Validação no FormRequest

```php
use LaravelLegends\PtBrValidator\Rules\Cpf;

public function rules(): array
{
    return ['cpf' => ['required', new Cpf]];
}
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.12 Formandos | CPF do formando (único) |
| 14.12 Responsáveis | CPF responsável cadastro/financeiro |
| 14.20 Cadastro Manual | CPFs |
| Filtros listagem | Busca por CPF |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Trivial |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Inputmask init global** em `resources/js/admin.js`:
    ```js
    import Inputmask from 'inputmask'
    Inputmask().mask(document.querySelectorAll('[data-inputmask]'))
    ```
2. **`font-mono`** no input para alinhamento perfeito dos dígitos
3. **Validação server-side obrigatória** — inputmask é UX, não segurança. Usar `LaravelLegends\PtBrValidator\Rules\Cpf`
4. **Livewire + inputmask:** salvar sem pontuação no banco — normalizar no `hydrate` ou cast
