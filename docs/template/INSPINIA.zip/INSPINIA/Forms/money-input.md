# Money Input (BRL — Centavos)

**Categoria:** Form (masked)
**Origem Inspinia:** `resources/views/form/other-plugin.blade.php` (Inputmask Currency)
**Plugins JS:** Inputmask 5.0.9

---

## Descrição

Input monetário BRL com máscara `R$ X.XXX,XX`. **Armazena em centavos (int)** conforme padrão do projeto (CLAUDE.md §7.3). O Livewire recebe o valor formatado na UI e converte para centavos via `MoneyHelper::toCents()` antes de persistir.

---

## Componente Blade Proposto

**Nome:** `<x-shared.money-input>`
**Arquivo:** `resources/views/components/shared/money-input.blade.php`

### Props

| Prop | Tipo | Default | Descrição |
|------|------|---------|-----------|
| `name` | `string` | — | — |
| `label` | `?string` | `'Valor'` | — |
| `prefix` | `string` | `'R$ '` | Prefixo do símbolo monetário |

### Código

```blade
{{-- resources/views/components/shared/money-input.blade.php --}}
@props([
    'name',
    'label' => 'Valor',
    'prefix' => 'R$ ',
    'hint' => null,
    'required' => false,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4">
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <input id="{{ $name }}" name="{{ $name }}" type="text"
           data-inputmask="'alias': 'currency', 'prefix': '{{ $prefix }}', 'groupSeparator': '.', 'radixPoint': ',', 'digits': 2, 'rightAlign': false"
           placeholder="{{ $prefix }}0,00"
           {{ $attributes->class([
               'form-input font-mono',
               'border-danger!' => $hasError,
           ]) }}
           @required($required) />

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

### Real (Programação 14.7)

```blade
<x-shared.money-input name="valor" label="Valor do Produto" wire:model="form.valor" required />
```

### Com MoneyHelper no Livewire

```php
// app/Livewire/Admin/Produtos/Programacoes/Form.php
use App\Support\MoneyHelper;

class Form extends Component
{
    public string $valor = ''; // "R$ 1.500,00"
    public int $valorCentavos = 0; // 150000

    public function updatedValor(string $value): void
    {
        $this->valorCentavos = MoneyHelper::toCents($value);
    }

    public function salvar(): void
    {
        Programacao::create([
            'produto_id' => $this->produto->id,
            'valor_centavos' => $this->valorCentavos,
            // ...
        ]);
    }
}
```

### MoneyHelper utility

```php
// app/Support/MoneyHelper.php
namespace App\Support;

class MoneyHelper
{
    public static function toCents(string $masked): int
    {
        $clean = preg_replace('/[^\d,]/', '', $masked);
        $clean = str_replace(',', '.', $clean);
        return (int) round(((float) $clean) * 100);
    }

    public static function format(int $cents, string $prefix = 'R$ '): string
    {
        return $prefix . number_format($cents / 100, 2, ',', '.');
    }
}
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.7 Programações | Valor (R$) |
| 14.9 Descontos | Valor/percentual |
| 14.12 Parcela actions | Alterar valor |
| 14.15 Configurações | Valor mínimo de parcela |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Média (conversão centavos) |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Inputmask alias `currency`** — handles thousand/decimal separators automatically
2. **Armazenar em centavos (int)** — PROIBIDO float para dinheiro (CLAUDE.md §7.3)
3. **MoneyHelper utility obrigatório** — centralizar conversão masked ↔ centavos
4. **`rightAlign: false`** — alinhamento à esquerda é mais natural em forms pt-BR
5. **Display em tabelas:** usar `MoneyHelper::format($valor_centavos)`
6. **Validação:** `'valor' => 'required|numeric|min:0|max:999999'` (em reais, não centavos — validar o masked input)
