# Select Search (Choices.js)

**Categoria:** Form
**Origem Inspinia:** `resources/views/form/select.blade.php`
**Plugins JS:** Choices.js 11.1.0
**Plugins CSS:** Choices.js CSS + `.form-input` do Inspinia

---

## Descrição

Select com busca (searchable). Usa Choices.js — lightweight, sem jQuery. Aplicado automaticamente em qualquer `<select>` com atributo `data-choices`. Suporta: single/multiple, groups, placeholder, remove-item, no-search.

---

## Código Original (Inspinia)

```html
<!-- Single -->
<select class="form-input" data-choices id="contrato" name="contrato_id">
    <option value="">Selecione...</option>
    <option value="1">2026-ENG-NOT — UNESP</option>
    <option value="2">2026-MED-DIU — USP</option>
</select>

<!-- Multiple -->
<select class="form-input" data-choices data-choices-multiple multiple name="tags[]">
    <option>Tag 1</option>
    <option>Tag 2</option>
</select>

<!-- Com groups -->
<select class="form-input" data-choices data-choices-groups name="produto_id">
    <option value="">Escolha um produto</option>
    <optgroup label="Fotografia">
        <option value="1">Álbum Premium</option>
        <option value="2">Ensaio Externo</option>
    </optgroup>
    <optgroup label="Vídeo">
        <option value="3">Filme da Colação</option>
    </optgroup>
</select>

<!-- Sem busca -->
<select class="form-input" data-choices data-choices-search-false name="status">
    <option>Ativo</option>
    <option>Cancelado</option>
</select>
```

---

## Componente Blade Proposto

**Nome:** `<x-shared.select-search>`
**Arquivo:** `resources/views/components/shared/select-search.blade.php`

### Props

Herda todas as props de `<x-shared.select>` + :

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `multiple` | `bool` | ❌ | `false` | Seleção múltipla |
| `searchable` | `bool` | ❌ | `true` | Habilita busca |
| `removeItem` | `bool` | ❌ | `true` | Botão X para remover seleção |

### Código

```blade
{{-- resources/views/components/shared/select-search.blade.php --}}
@props([
    'name',
    'label' => null,
    'options' => null,
    'placeholder' => 'Selecione...',
    'hint' => null,
    'required' => false,
    'multiple' => false,
    'searchable' => true,
    'removeItem' => true,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4" wire:ignore>
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <select id="{{ $name }}" name="{{ $multiple ? $name . '[]' : $name }}"
            data-choices
            @if($multiple) multiple data-choices-multiple @endif
            @if(!$searchable) data-choices-search-false @endif
            @if($removeItem) data-choices-removeItem @endif
            data-placeholder="{{ $placeholder }}"
            {{ $attributes->class([
                'form-input',
                'border-danger!' => $hasError,
            ]) }}
            @required($required)>
        <option value="">{{ $placeholder }}</option>

        @if($options)
            @foreach($options as $value => $optionLabel)
                <option value="{{ $value }}">{{ $optionLabel }}</option>
            @endforeach
        @else
            {{ $slot }}
        @endif
    </select>

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

### Real (Instituição no form de Contrato 14.4)

```blade
<x-shared.select-search
    name="instituicao_id"
    label="Instituição"
    :options="$instituicoes->pluck('nome_fantasia', 'id')->toArray()"
    wire:model.live="contrato.instituicao_id"
    required />
```

### Real (Tags input via multiple — 14.15 Configurações)

```blade
<x-shared.select-search
    name="dias_vencimento"
    label="Dias de Vencimento"
    multiple
    :options="array_combine(range(1, 31), range(1, 31))"
    placeholder="Adicione dias..."
    wire:model="config.dias_vencimento" />
```

### Com groups (produtos por categoria)

```blade
<x-shared.select-search name="produto_id" label="Produto" wire:model="adesao.produto_id">
    <option value="">Escolha um produto</option>
    @foreach($categorias as $categoria)
        <optgroup label="{{ $categoria->nome }}">
            @foreach($categoria->produtos as $produto)
                <option value="{{ $produto->id }}">{{ $produto->nome }}</option>
            @endforeach
        </optgroup>
    @endforeach
</x-shared.select-search>
```

---

## Quando Usar ✅

- Listas com > 10 opções
- Seleção múltipla (tags, arrays)
- Campos de relacionamento (contrato, instituição, formando)
- Substituto de Tagify (ver TRIAGEM.md §4)

## Quando NÃO Usar ❌

- Listas curtas (< 10) → `<x-shared.select>` nativo é mais leve
- Mobile onde native select é preferível
- Campos async (busca no servidor) → considerar Livewire custom com debounce

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.3 Instituições | — |
| 14.4 Contratos | Instituição (searchable) |
| 14.6 Produtos | Contrato, Categoria (searchable) |
| 14.8 Condições | Modalidade Complementar |
| 14.10 Termos Produto | Vincular termo |
| 14.12 Formandos | Filtros Contrato/Curso/Período, Pacote |
| 14.13 Parcelas | Filtros |
| 14.15 Configurações | **Tags de dias** (substituto de Tagify) |
| 14.14 Simulador | Contrato, Produto, Modalidade |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim (crítico) |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Média |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **`wire:ignore` obrigatório** no wrapper — Choices.js manipula o DOM, conflita com Livewire se re-renderizar
2. **Update do Livewire via `wire:model` no select interno** — funciona porque Choices.js sincroniza o `<select>` nativo
3. **Re-inicializar ao mudar opções:** se o array `options` mudar dinamicamente (filtros em cascata), precisamos re-inicializar Choices. Usar `$refresh` + destroy/recreate
4. **Choices.js init global** em `resources/js/admin.js`:
    ```js
    import Choices from 'choices.js'
    import 'choices.js/public/assets/styles/choices.min.css'
    document.querySelectorAll('[data-choices]').forEach(el => new Choices(el, {...}))
    ```
5. **Substituto de Tagify** confirmado — para o caso 14.15 (tags de dias), Choices multiple cobre bem
6. **Multiple + Livewire:** nome vira `dias[]` automaticamente — validação Laravel trata
