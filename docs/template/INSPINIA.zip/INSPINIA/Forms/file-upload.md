# File Upload (Dropzone)

**Categoria:** Form
**Origem Inspinia:** `resources/views/form/fileuploads.blade.php`
**Plugins JS:** Dropzone 6.0.0-beta.2
**Plugins CSS:** Dropzone CSS custom

---

## Descrição

Upload de arquivos com drag-and-drop, preview e múltiplos arquivos. Usa Dropzone. Para uploads simples via Livewire, considerar `wire:model` direto em `<input type="file">`. Este componente é para uploads com preview rico (logo, fotos, avatars).

---

## Código Original (Inspinia — essência)

```html
<form action="/upload" class="min-h-37.5 border-2 border-default-300 border-dashed rounded-lg p-5"
      data-plugin="dropzone"
      data-previews-container="#file-previews"
      data-upload-preview-template="#uploadPreviewTemplate"
      id="myAwesomeDropzone"
      method="post">
    <div class="dz-message needsclick text-center my-8">
        <div class="size-11 mx-auto mb-base">
            <span class="btn btn-icon size-11 bg-info/15 text-info rounded-full">
                <i class="iconify tabler--cloud-upload text-2xl"></i>
            </span>
        </div>
        <h4 class="text-lg mb-3">Arraste arquivos aqui ou clique para enviar</h4>
        <p class="text-default-400 italic mb-5">Você pode arrastar imagens aqui</p>
    </div>
</form>

<div class="dropzone-previews mt-5" id="file-previews"></div>
<div class="hidden" id="uploadPreviewTemplate">
    <div class="card mt-1 border border-dashed border-default-300">
        <div class="p-3 flex items-center">
            <img class="size-8 rounded me-3" data-dz-thumbnail src="#" />
            <div>
                <a data-dz-name class="font-semibold text-primary"></a>
                <p class="text-default-400" data-dz-size></p>
            </div>
            <a class="btn btn-sm text-danger ms-auto" data-dz-remove>
                <i class="iconify tabler--x"></i>
            </a>
        </div>
    </div>
</div>
```

---

## Componente Blade Proposto

**Nome:** `<x-shared.file-upload>`
**Arquivo:** `resources/views/components/shared/file-upload.blade.php`

### Props

| Prop | Tipo | Default | Descrição |
|------|------|---------|-----------|
| `name` | `string` | — | — |
| `label` | `?string` | `null` | — |
| `accept` | `string` | `'image/*'` | MIME types aceitos |
| `maxSize` | `int` | `2` | Tamanho máx (MB) |
| `multiple` | `bool` | `false` | — |
| `preview` | `?string` | `null` | URL da imagem atual (edição) |

### Código

```blade
{{-- resources/views/components/shared/file-upload.blade.php --}}
@props([
    'name',
    'label' => null,
    'accept' => 'image/*',
    'maxSize' => 2,
    'multiple' => false,
    'preview' => null,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4">
    @if($label)<label class="form-label">{{ $label }}</label>@endif

    {{-- Preview atual (se edição) --}}
    @if($preview)
        <div class="mb-2">
            <img src="{{ $preview }}" alt="Preview atual" class="max-h-32 rounded border" />
        </div>
    @endif

    <div class="border-2 border-default-300 border-dashed rounded-lg p-6 text-center
                hover:border-primary transition cursor-pointer
                {{ $hasError ? 'border-danger' : '' }}"
         x-data="{
             preview: @js($preview),
             fileName: null,
             async onFile(e) {
                 const file = e.target.files[0]
                 if (!file) return
                 if (file.size > {{ $maxSize }} * 1024 * 1024) {
                     this.$dispatch('toast', { variant: 'danger', message: 'Arquivo excede {{ $maxSize }}MB' })
                     return
                 }
                 this.fileName = file.name
                 if (file.type.startsWith('image/')) {
                     this.preview = URL.createObjectURL(file)
                 }
             }
         }"
         @click="$refs.input.click()">
        <input x-ref="input" type="file" class="hidden"
               name="{{ $name }}"
               accept="{{ $accept }}"
               @if($multiple) multiple @endif
               {{ $attributes }}
               @change="onFile($event)" />

        <div x-show="!preview && !fileName">
            <span class="btn btn-icon size-11 bg-info/15 text-info rounded-full inline-flex">
                <i class="iconify tabler--cloud-upload text-2xl"></i>
            </span>
            <p class="mt-3 text-sm">Clique ou arraste um arquivo</p>
            <p class="text-xs text-default-400 mt-1">Máx {{ $maxSize }}MB</p>
        </div>

        <div x-show="preview">
            <img :src="preview" class="max-h-32 mx-auto rounded" />
            <p class="text-xs text-default-400 mt-2" x-text="fileName || 'Imagem atual'"></p>
        </div>
    </div>

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

### Livewire (upload simples sem Dropzone)

```blade
<x-shared.file-upload
    name="logo"
    label="Logo da Instituição"
    accept="image/png,image/jpeg"
    :max-size="2"
    :preview="$instituicao?->logo_url"
    wire:model="logo" />
```

```php
use Livewire\WithFileUploads;

class Form extends Component
{
    use WithFileUploads;

    public $logo;

    public function salvar(): void
    {
        $path = $this->logo?->store('instituicoes/logos', 'public');
        $this->instituicao->update(['logo_path' => $path]);
    }
}
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.3 Instituições | Logo (JPG/PNG, 2MB) |
| 14.6 Produtos | Imagem do produto (2MB) |
| 14.12 Formandos | Foto |
| Parking lot | FilePond alternativo |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Média |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Livewire nativo em vez de Dropzone** — para uploads simples (logo, imagem única), Livewire `WithFileUploads` é mais simples e não precisa de jQuery
2. **Dropzone fica disponível** no parking lot para casos com upload em lote (galeria, batch)
3. **Preview via Object URL** em Alpine — funciona offline sem dependência
4. **`$maxSize` em MB** → validação client-side (UX) + server-side Laravel obrigatória
5. **Acceptance types** via mime: `image/*`, `application/pdf`, etc.
6. **Armazenamento:** `storage/app/public/instituicoes/logos/` + `php artisan storage:link`
