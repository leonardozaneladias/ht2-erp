# CEP Input (+ ViaCEP Autocomplete)

**Categoria:** Form (masked + autocomplete)
**Origem Inspinia:** `resources/views/form/other-plugin.blade.php` (Inputmask)
**Plugins JS:** Inputmask 5.0.9 + fetch nativo (ViaCEP API)

---

## Descrição

Input CEP com máscara `XXXXX-XXX` + **autocompletar endereço via ViaCEP** (API pública gratuita). Ao digitar os 8 dígitos, dispara fetch para `https://viacep.com.br/ws/{cep}/json/` e preenche logradouro/bairro/cidade/UF via Livewire.

---

## Componente Blade Proposto

**Nome:** `<x-shared.cep-input>`
**Arquivo:** `resources/views/components/shared/cep-input.blade.php`

### Props

| Prop | Tipo | Default | Descrição |
|------|------|---------|-----------|
| `name` | `string` | — | — |
| `label` | `?string` | `'CEP'` | — |
| `target` | `?string` | `null` | Método Livewire a chamar ao completar (recebe resposta ViaCEP) |

### Código

```blade
{{-- resources/views/components/shared/cep-input.blade.php --}}
@props([
    'name',
    'label' => 'CEP',
    'hint' => null,
    'required' => false,
    'target' => null,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4" x-data="{
    loading: false,
    async buscaCep(cep) {
        const clean = cep.replace(/\D/g, '')
        if (clean.length !== 8) return
        this.loading = true
        try {
            const res = await fetch(`https://viacep.com.br/ws/${clean}/json/`)
            const data = await res.json()
            if (data.erro) {
                this.$dispatch('toast', { variant: 'warning', message: 'CEP não encontrado' })
                return
            }
            @if($target)
                $wire.call('{{ $target }}', data)
            @else
                $wire.set('form.logradouro', data.logradouro || '')
                $wire.set('form.bairro', data.bairro || '')
                $wire.set('form.cidade', data.localidade || '')
                $wire.set('form.uf', data.uf || '')
            @endif
        } catch (e) {
            this.$dispatch('toast', { variant: 'danger', message: 'Erro ao buscar CEP' })
        } finally {
            this.loading = false
        }
    }
}">
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <div class="input-icon-group">
        <i class="iconify tabler--map-pin input-icon"></i>
        <input id="{{ $name }}" name="{{ $name }}" type="text"
               data-inputmask="'mask': '99999-999'"
               placeholder="00000-000"
               x-on:blur="buscaCep($el.value)"
               {{ $attributes->class([
                   'form-input font-mono',
                   'border-danger!' => $hasError,
               ]) }}
               @required($required) />
        <span x-show="loading" class="absolute end-3 top-1/2 -translate-y-1/2">
            <i class="iconify tabler--loader-2 animate-spin text-default-400"></i>
        </span>
    </div>

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

### Auto-preenche campos form.*

```blade
<x-shared.cep-input name="cep" wire:model="form.cep" required />
<x-shared.input name="logradouro" label="Logradouro" wire:model="form.logradouro" />
<x-shared.input name="bairro" label="Bairro" wire:model="form.bairro" />
<x-shared.input name="cidade" label="Cidade" wire:model="form.cidade" />
<x-shared.select name="uf" label="UF" :options="$ufs" wire:model="form.uf" />
```

### Custom handler (via target)

```blade
<x-shared.cep-input name="cep_residencial" target="preencherEnderecoResidencial" wire:model="formando.cep_residencial" />
```

```php
public function preencherEnderecoResidencial(array $data): void
{
    $this->formando->endereco_residencial = $data['logradouro'] . ', ' . $data['bairro'];
    $this->formando->cidade_residencial = $data['localidade'];
    $this->formando->uf_residencial = $data['uf'];
}
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.3 Instituições | CEP com auto-preenchimento (explícito no PRD) |
| 14.12 Formandos (endereço) | CEP |
| 14.20 Cadastro Manual | CEP + responsáveis |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Média (Alpine + fetch) |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **ViaCEP é gratuito e público** — sem API key
2. **Rate limit:** 100 req/segundo por IP — cache no lado do servidor se virar problema
3. **Fallback:** se ViaCEP falhar, toast warning e deixar usuário preencher manualmente
4. **`x-on:blur`** em vez de `input` — evita chamadas excessivas enquanto digita
5. **Target opcional** — se omitido, assume campos `form.logradouro/bairro/cidade/uf`. Custom via `target`
6. **Dispatch toast** via evento global — ver `toast.md`
7. **Loading indicator** inline à direita durante fetch
