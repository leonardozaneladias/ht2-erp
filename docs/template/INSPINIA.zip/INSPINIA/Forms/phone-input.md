# Phone Input (BR)

**Categoria:** Form (masked)
**Origem Inspinia:** `resources/views/form/other-plugin.blade.php` (Inputmask)
**Plugins JS:** Inputmask 5.0.9

---

## Descrição

Input telefone brasileiro com máscara **adaptativa** para celular (11 dígitos `(XX) XXXXX-XXXX`) ou fixo (10 dígitos `(XX) XXXX-XXXX`). Usa inputmask com alias dinâmico.

---

## Componente Blade Proposto

**Nome:** `<x-shared.phone-input>`
**Arquivo:** `resources/views/components/shared/phone-input.blade.php`

```blade
@props([
    'name',
    'label' => 'Telefone',
    'hint' => null,
    'required' => false,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4">
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <div class="input-icon-group">
        <i class="iconify tabler--phone input-icon"></i>
        <input id="{{ $name }}" name="{{ $name }}" type="tel"
               data-inputmask="'mask': ['(99) 9999-9999', '(99) 99999-9999']"
               placeholder="(00) 00000-0000"
               {{ $attributes->class([
                   'form-input font-mono',
                   'border-danger!' => $hasError,
               ]) }}
               @required($required) />
    </div>

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

```blade
<x-shared.phone-input name="telefone" wire:model="formando.telefone" />
<x-shared.phone-input name="contato_instituicao" label="Telefone de Contato" wire:model="instituicao.telefone" />
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.3 Instituições | Telefone (opcional) |
| 14.12 Formandos | Telefone |
| 14.12 Responsáveis | Telefone |
| 14.20 Cadastro Manual | Telefones |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Trivial |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Array de masks** no Inputmask — escolhe automaticamente entre 10 e 11 dígitos
2. **Validação relaxada** — aceita sem DDD? Não. Regex server-side: `/^\(\d{2}\) \d{4,5}-\d{4}$/`
3. **Salvar sem máscara** no banco — normalizar via mutator Eloquent:
    ```php
    protected function telefone(): Attribute
    {
        return Attribute::make(
            get: fn($v) => preg_replace('/(\d{2})(\d)/', '($1) $2', $v),
            set: fn($v) => preg_replace('/\D/', '', $v),
        );
    }
    ```
