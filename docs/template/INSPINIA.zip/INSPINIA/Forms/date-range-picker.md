# Date Range Picker

**Categoria:** Form
**Origem Inspinia:** `resources/views/form/pickers.blade.php`
**Plugins JS:** Flatpickr 4.6.13 (modo range) — alternativa a Daterangepicker 3.1.0 (jQuery)
**Plugins CSS:** Flatpickr CSS

---

## Descrição

Seletor de **intervalo de datas** (ex: "01/01/2026 até 31/12/2026"). Usaremos Flatpickr em modo range (atributo `data-mode="range"`) para manter consistência com o `<x-shared.date-picker>` — evita duas bibliotecas de datepicker. O Daterangepicker jQuery vai para o parking lot.

---

## Código Original (Inspinia — Flatpickr range)

```html
<input class="form-input"
       data-provider="flatpickr"
       data-date-format="d/m/Y"
       data-mode="range"
       type="text"
       placeholder="Intervalo de datas" />
```

---

## Componente Blade Proposto

**Nome:** `<x-shared.date-range-picker>`
**Arquivo:** `resources/views/components/shared/date-range-picker.blade.php`

### Props

Similar a `<x-shared.date-picker>` sem `enableTime`:

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `name` | `string` | ✅ | — | — |
| `label` | `?string` | ❌ | `null` | — |
| `format` | `string` | ❌ | `'d/m/Y'` | — |
| `minDate` | `?string` | ❌ | `null` | — |
| `maxDate` | `?string` | ❌ | `null` | — |
| `hint` | `?string` | ❌ | `null` | — |
| `required` | `bool` | ❌ | `false` | — |

### Código

```blade
{{-- resources/views/components/shared/date-range-picker.blade.php --}}
@props([
    'name',
    'label' => null,
    'format' => 'd/m/Y',
    'minDate' => null,
    'maxDate' => null,
    'hint' => null,
    'required' => false,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4" wire:ignore>
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <div class="input-icon-group">
        <i class="iconify tabler--calendar-event input-icon"></i>
        <input id="{{ $name }}" name="{{ $name }}" type="text"
               data-provider="flatpickr"
               data-date-format="{{ $format }}"
               data-mode="range"
               @if($minDate) data-mindate="{{ $minDate }}" @endif
               @if($maxDate) data-maxdate="{{ $maxDate }}" @endif
               {{ $attributes->class([
                   'form-input',
                   'border-danger!' => $hasError,
               ]) }}
               @required($required)
               placeholder="Selecione o intervalo" />
    </div>

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

### Real (Filtro de Formandos 14.12)

```blade
<x-shared.date-range-picker
    name="data_adesao"
    label="Data de Adesão"
    wire:model.live.debounce.500ms="filtros.data_adesao" />
```

### Real (Filtro de Parcelas 14.13)

```blade
<x-shared.date-range-picker
    name="vencimento"
    label="Vencimento"
    wire:model.live="filtros.vencimento" />
```

### Real (Relatórios 14.17)

```blade
<x-shared.date-range-picker
    name="periodo"
    label="Período do Relatório"
    wire:model="filtros.periodo"
    required />
```

---

## Mapeamento no PRD

| Tela | Seção PRD | Uso |
|------|-----------|-----|
| Formandos | 14.12 | Filtro Data Adesão |
| Parcelas | 14.13 | Filtro Vencimento |
| Relatórios | 14.17 | Período filtrado |
| Dashboard | 14.2 | Filtros de período opcionais |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Simples |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Flatpickr mode range** em vez de Daterangepicker jQuery — consistência
2. **Daterangepicker fica no parking lot** (já está no package.json, pode ser reativado)
3. **Valor retornado:** Flatpickr em mode range retorna string `"01/01/2026 to 31/12/2026"`. Parsing no backend:
    ```php
    [$inicio, $fim] = array_map(
        fn($d) => Carbon::createFromFormat('d/m/Y', trim($d)),
        explode('to', $this->filtros_vencimento)
    );
    ```
4. **Melhor alternativa:** criar 2 Livewire properties (`data_inicio`, `data_fim`) e usar x-on:change do Flatpickr para emitir ambas. Mais complexo mas parsing fica centralizado
5. **`wire:model.live.debounce`** — evita re-render a cada seleção
6. **Ícone `calendar-event`** diferente do datepicker simples para diferenciar visualmente
