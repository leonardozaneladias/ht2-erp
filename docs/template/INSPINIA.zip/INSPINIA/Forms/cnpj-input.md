# CNPJ Input

**Categoria:** Form (masked)
**Origem Inspinia:** `resources/views/form/other-plugin.blade.php` (Inputmask)
**Plugins JS:** Inputmask 5.0.9

---

## Descrição

Input CNPJ brasileiro com máscara `XX.XXX.XXX/XXXX-XX`. Mesmo padrão do `<x-shared.cpf-input>`.

---

## Componente Blade Proposto

**Nome:** `<x-shared.cnpj-input>`
**Arquivo:** `resources/views/components/shared/cnpj-input.blade.php`

```blade
@props([
    'name',
    'label' => 'CNPJ',
    'hint' => null,
    'required' => false,
])

@php $hasError = $errors->has($name); @endphp

<div class="mb-4">
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <input id="{{ $name }}" name="{{ $name }}" type="text"
           data-inputmask="'mask': '99.999.999/9999-99'"
           placeholder="00.000.000/0000-00"
           {{ $attributes->class([
               'form-input font-mono',
               'border-danger!' => $hasError,
           ]) }}
           @required($required) />

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplo de Uso

```blade
<x-shared.cnpj-input name="cnpj" wire:model="instituicao.cnpj" required />
```

### Validação

```php
use LaravelLegends\PtBrValidator\Rules\Cnpj;

public function rules(): array
{
    return ['cnpj' => ['required', new Cnpj, 'unique:instituicoes,cnpj']];
}
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.3 Instituições | CNPJ (único) |
| Parking lot: companies/clients (apps) | — |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Trivial |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **Única diferença do CPF** é o formato da máscara e a validação Rule
2. **`unique`** no banco obrigatório
3. **Validação server-side** via `Cnpj` do pt-br-validator
