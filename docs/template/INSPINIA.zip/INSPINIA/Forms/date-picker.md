# Date Picker (Flatpickr)

**Categoria:** Form
**Origem Inspinia:** `resources/views/form/pickers.blade.php`
**Plugins JS:** Flatpickr 4.6.13
**Plugins CSS:** Flatpickr CSS

---

## Descrição

Seletor de data usando Flatpickr. Aplicado via `data-provider="flatpickr"`. Suporta formato customizado, min/max date, default date, enable-time, disabled dates, modo range.

---

## Código Original (Inspinia)

```html
<!-- Básico -->
<input class="form-input"
       data-provider="flatpickr"
       data-date-format="d/m/Y"
       type="text"
       placeholder="Selecione uma data" />

<!-- Com hora -->
<input class="form-input"
       data-provider="flatpickr"
       data-date-format="d/m/Y H:i"
       data-enable-time
       type="text" />

<!-- Min/Max -->
<input class="form-input"
       data-provider="flatpickr"
       data-date-format="d/m/Y"
       data-mindate="today"
       data-maxdate="2026-12-31"
       type="text" />

<!-- Default -->
<input class="form-input"
       data-provider="flatpickr"
       data-date-format="d/m/Y"
       data-default-date="2026-04-11"
       type="text" />
```

---

## Componente Blade Proposto

**Nome:** `<x-shared.date-picker>`
**Arquivo:** `resources/views/components/shared/date-picker.blade.php`

### Props

| Prop | Tipo | Obrigatório | Default | Descrição |
|------|------|:-----------:|---------|-----------|
| `name` | `string` | ✅ | — | — |
| `label` | `?string` | ❌ | `null` | — |
| `format` | `string` | ❌ | `'d/m/Y'` | Formato pt-BR |
| `enableTime` | `bool` | ❌ | `false` | Habilita seleção de hora |
| `minDate` | `?string` | ❌ | `null` | "today" ou data Y-m-d |
| `maxDate` | `?string` | ❌ | `null` | — |
| `hint` | `?string` | ❌ | `null` | — |
| `required` | `bool` | ❌ | `false` | — |

### Código

```blade
{{-- resources/views/components/shared/date-picker.blade.php --}}
@props([
    'name',
    'label' => null,
    'format' => 'd/m/Y',
    'enableTime' => false,
    'minDate' => null,
    'maxDate' => null,
    'hint' => null,
    'required' => false,
])

@php
    $hasError = $errors->has($name);
    $finalFormat = $enableTime ? $format . ' H:i' : $format;
@endphp

<div class="mb-4" wire:ignore>
    @if($label)
        <label class="form-label" for="{{ $name }}">
            {{ $label }}
            @if($required)<span class="text-danger">*</span>@endif
        </label>
    @endif

    <div class="input-icon-group">
        <i class="iconify tabler--calendar input-icon"></i>
        <input id="{{ $name }}" name="{{ $name }}" type="text"
               data-provider="flatpickr"
               data-date-format="{{ $finalFormat }}"
               @if($enableTime) data-enable-time @endif
               @if($minDate) data-mindate="{{ $minDate }}" @endif
               @if($maxDate) data-maxdate="{{ $maxDate }}" @endif
               {{ $attributes->class([
                   'form-input',
                   'border-danger!' => $hasError,
               ]) }}
               @required($required)
               placeholder="dd/mm/aaaa" />
    </div>

    @if($hasError)
        <small class="text-danger mt-1 block text-xs">{{ $errors->first($name) }}</small>
    @elseif($hint)
        <small class="text-default-400 mt-1 block text-xs">{{ $hint }}</small>
    @endif
</div>
```

---

## Exemplos de Uso

### Real (Contrato 14.4)

```blade
<x-shared.date-picker name="data_inicio" label="Data Início" wire:model="contrato.data_inicio" required />
<x-shared.date-picker name="data_evento" label="Data do Evento" min-date="today" wire:model="contrato.data_evento" />
```

### Real (Programação 14.7)

```blade
<div class="grid grid-cols-2 gap-4">
    <x-shared.date-picker name="inicio" label="Data Início" wire:model="form.inicio" required />
    <x-shared.date-picker name="fim" label="Data Fim" wire:model="form.fim" required />
</div>
```

---

## Mapeamento no PRD

| Tela | Uso |
|------|-----|
| 14.4 Contratos | Data início, Data evento |
| 14.6 Produtos | Data início/fim venda |
| 14.7 Programações | Data início/fim |
| 14.9 Descontos | Data início/fim vigência |
| 14.14 Simulador | Data adesão simulada |
| 14.4 Tab 5 Reajustes | Data aplicação |

---

## Classificação

| Critério | Valor |
|----------|-------|
| **Vai usar** | 🟢 Sim |
| **Prioridade** | P2 (Onda 3) |
| **Complexidade** | Simples |
| **Status** | 🔴 Não iniciado |

---

## Notas de Adaptação

1. **`wire:ignore` obrigatório** — Flatpickr manipula o input
2. **Formato pt-BR `d/m/Y`** padrão — diferente do Inspinia que usa `d M, Y`
3. **Locale pt-BR:** importar `flatpickr/dist/l10n/pt.js` e setar no init global
4. **Init global** em `resources/js/admin.js`:
    ```js
    import flatpickr from 'flatpickr'
    import { Portuguese } from 'flatpickr/dist/l10n/pt.js'
    flatpickr.localize(Portuguese)
    document.querySelectorAll('[data-provider="flatpickr"]').forEach(el => flatpickr(el, {
        dateFormat: el.dataset.dateFormat,
        enableTime: el.hasAttribute('data-enable-time'),
        minDate: el.dataset.mindate,
        maxDate: el.dataset.maxdate,
    }))
    ```
5. **Ícone calendário** à esquerda via `input-icon-group`
6. **Livewire sync:** Flatpickr atualiza o input nativo → `wire:model` captura normalmente
